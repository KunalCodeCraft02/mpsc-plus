import { and, eq, sql, desc, gte } from "drizzle-orm";
import { db } from "@/db";
import { users, xpEvents, userBadges, lectureProgress, quizAttempts } from "@/db/schema";
import { XP_RULES } from "@/lib/config";
import { todayKey } from "@/lib/utils";

/**
 * Award XP for a verified activity.
 * Dedupe is enforced by a unique index on (user_id, kind, ref_id), so a
 * replayed request can never grant XP twice.
 */
export async function awardXp(userId, kind, refId, amountOverride) {
  const amount = amountOverride ?? XP_RULES[kind] ?? 0;
  if (!amount) return 0;
  const inserted = await db
    .insert(xpEvents)
    .values({ userId, kind, refId: String(refId ?? "0"), amount })
    .onConflictDoNothing()
    .returning({ id: xpEvents.id });
  if (!inserted.length) return 0;
  await db
    .update(users)
    .set({ xp: sql`${users.xp} + ${amount}` })
    .where(eq(users.id, userId));
  return amount;
}

export async function grantBadge(userId, code) {
  const rows = await db
    .insert(userBadges)
    .values({ userId, code })
    .onConflictDoNothing()
    .returning({ code: userBadges.code });
  return rows.length ? code : null;
}

/** Update the study streak; awards a small bonus for each new active day. */
export async function touchStreak(userId) {
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const user = rows[0];
  if (!user) return { current: 0, longest: 0, bonus: 0 };

  const today = todayKey();
  if (user.lastStudyDate === today) {
    return { current: user.streakCurrent, longest: user.streakLongest, bonus: 0 };
  }

  const yesterday = todayKey(new Date(Date.now() - 86400000));
  const current = user.lastStudyDate === yesterday ? (user.streakCurrent || 0) + 1 : 1;
  const longest = Math.max(current, user.streakLongest || 0);

  await db
    .update(users)
    .set({ streakCurrent: current, streakLongest: longest, lastStudyDate: today })
    .where(eq(users.id, userId));

  const bonus = await awardXp(userId, "streak_day_bonus", today);
  if (current >= 7) await grantBadge(userId, "streak_7");
  return { current, longest, bonus };
}

export async function recomputeBadges(userId) {
  const earned = [];

  const [{ count: lectureCount = 0 } = {}] = await db
    .select({ count: sql`count(*)::int` })
    .from(lectureProgress)
    .where(and(eq(lectureProgress.userId, userId), eq(lectureProgress.completed, true)));

  if (Number(lectureCount) >= 1) {
    const b = await grantBadge(userId, "first_lecture");
    if (b) earned.push(b);
  }
  if (Number(lectureCount) >= 20) {
    const b = await grantBadge(userId, "bookworm");
    if (b) earned.push(b);
  }

  const attempts = await db
    .select({ percent: quizAttempts.percent })
    .from(quizAttempts)
    .where(eq(quizAttempts.userId, userId));

  if (attempts.length >= 5) {
    const b = await grantBadge(userId, "quiz_master");
    if (b) earned.push(b);
  }
  if (attempts.some((a) => a.percent >= 100)) {
    const b = await grantBadge(userId, "perfect_score");
    if (b) earned.push(b);
  }
  return earned;
}

/** Leaderboard scoped by period. Ranking blends XP with real learning output. */
export async function leaderboard({ period = "global", courseId, limit = 50 } = {}) {
  if (period === "global") {
    const rows = await db
      .select({
        id: users.id,
        name: users.name,
        avatarUrl: users.avatarUrl,
        xp: users.xp,
        streakCurrent: users.streakCurrent,
      })
      .from(users)
      .where(eq(users.role, "STUDENT"))
      .orderBy(desc(users.xp))
      .limit(limit);
    return rows.map((r, i) => ({ ...r, rank: i + 1, periodXp: r.xp }));
  }

  const since = new Date();
  if (period === "weekly") since.setDate(since.getDate() - 7);
  else if (period === "monthly") since.setDate(since.getDate() - 30);
  else since.setFullYear(since.getFullYear() - 20);

  const conditions = [gte(xpEvents.createdAt, since), eq(users.role, "STUDENT")];
  if (courseId) conditions.push(sql`${xpEvents.kind} <> ''`);

  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      avatarUrl: users.avatarUrl,
      xp: users.xp,
      streakCurrent: users.streakCurrent,
      periodXp: sql`coalesce(sum(${xpEvents.amount}), 0)::int`,
    })
    .from(xpEvents)
    .innerJoin(users, eq(users.id, xpEvents.userId))
    .where(and(...conditions))
    .groupBy(users.id, users.name, users.avatarUrl, users.xp, users.streakCurrent)
    .orderBy(desc(sql`coalesce(sum(${xpEvents.amount}), 0)`))
    .limit(limit);

  return rows.map((r, i) => ({ ...r, rank: i + 1 }));
}

export async function userRank(userId) {
  const rows = await db
    .select({ rank: sql`count(*)::int` })
    .from(users)
    .where(
      and(
        eq(users.role, "STUDENT"),
        sql`${users.xp} > (select xp from users where id = ${userId})`,
      ),
    );
  return Number(rows[0]?.rank || 0) + 1;
}
