import { and, asc, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  courses,
  subjects,
  chapters,
  lectures,
  pdfs,
  quizzes,
  questions,
  users,
  notifications,
  auditLogs,
  enrollments,
  lectureProgress,
  quizAttempts,
} from "@/db/schema";
import { HttpError } from "@/server/auth";
import { SCHEMAS, notificationSchema } from "@/server/validation";
import { extractYoutubeId, slugify } from "@/lib/utils";

export const ENTITIES = {
  courses: {
    table: courses,
    searchCols: [courses.title, courses.titleMr, courses.instructor, courses.category],
    sortable: { createdAt: courses.createdAt, title: courses.title, price: courses.price },
    defaultSort: desc(courses.createdAt),
    schema: SCHEMAS.courses,
  },
  subjects: {
    table: subjects,
    searchCols: [subjects.name, subjects.nameMr],
    sortable: { order: subjects.orderIndex, title: subjects.name },
    defaultSort: asc(subjects.orderIndex),
    schema: SCHEMAS.subjects,
  },
  chapters: {
    table: chapters,
    searchCols: [chapters.title, chapters.titleMr],
    sortable: { order: chapters.orderIndex, title: chapters.title },
    defaultSort: asc(chapters.orderIndex),
    schema: SCHEMAS.chapters,
  },
  lectures: {
    table: lectures,
    searchCols: [lectures.title, lectures.titleMr, lectures.description],
    sortable: { createdAt: lectures.createdAt, order: lectures.orderIndex, title: lectures.title },
    defaultSort: desc(lectures.createdAt),
    schema: SCHEMAS.lectures,
  },
  pdfs: {
    table: pdfs,
    searchCols: [pdfs.title, pdfs.titleMr, pdfs.description],
    sortable: { createdAt: pdfs.createdAt, title: pdfs.title },
    defaultSort: desc(pdfs.createdAt),
    schema: SCHEMAS.pdfs,
  },
  quizzes: {
    table: quizzes,
    searchCols: [quizzes.title, quizzes.titleMr, quizzes.description],
    sortable: { createdAt: quizzes.createdAt, title: quizzes.title },
    defaultSort: desc(quizzes.createdAt),
    schema: SCHEMAS.quizzes,
  },
  students: {
    table: users,
    searchCols: [users.name, users.email, users.mobile],
    sortable: { createdAt: users.createdAt, name: users.name, xp: users.xp },
    defaultSort: desc(users.createdAt),
    readOnly: true,
  },
  notifications: {
    table: notifications,
    searchCols: [notifications.title, notifications.titleMr, notifications.body],
    sortable: { createdAt: notifications.createdAt },
    defaultSort: desc(notifications.createdAt),
    schema: notificationSchema,
  },
};

export function entityConf(entity) {
  const conf = ENTITIES[entity];
  if (!conf) throw new HttpError(404, `Unknown resource: ${entity}`);
  return conf;
}

export async function logAudit(admin, action, entity, entityId, detail) {
  try {
    await db.insert(auditLogs).values({
      adminId: admin?.id ?? null,
      adminName: admin?.name ?? "system",
      action,
      entity,
      entityId: String(entityId ?? ""),
      detail: detail ? String(detail).slice(0, 500) : null,
    });
  } catch {
    /* audit failures must never break the operation */
  }
}

function emptyToNull(value) {
  return value === "" || value === undefined ? null : value;
}

/** Normalise validated payloads into database columns. */
export function toRow(entity, data) {
  if (entity === "courses") {
    return {
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      slug: `${slugify(data.title)}-${Math.random().toString(36).slice(2, 6)}`,
      description: emptyToNull(data.description),
      descriptionMr: emptyToNull(data.descriptionMr),
      thumbnailUrl: emptyToNull(data.thumbnailUrl),
      instructor: emptyToNull(data.instructor),
      category: emptyToNull(data.category),
      language: data.language || "Marathi",
      isFree: !!data.isFree,
      price: data.isFree ? 0 : Math.round(data.price || 0),
      currency: data.currency || "INR",
      validityDays: data.isFree ? 0 : Math.round(data.validityDays || 0),
      published: !!data.published,
    };
  }
  if (entity === "subjects") {
    return {
      courseId: data.courseId,
      name: data.name,
      nameMr: emptyToNull(data.nameMr),
      description: emptyToNull(data.description),
      orderIndex: data.orderIndex || 1,
    };
  }
  if (entity === "chapters") {
    return {
      courseId: data.courseId,
      subjectId: data.subjectId,
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      description: emptyToNull(data.description),
      orderIndex: data.orderIndex || 1,
    };
  }
  if (entity === "lectures") {
    const youtubeId = extractYoutubeId(data.youtubeId || data.youtubeUrl || "");
    if (!youtubeId) {
      throw new HttpError(422, "Enter a valid YouTube URL or 11-character video ID.");
    }
    return {
      courseId: data.courseId,
      subjectId: data.subjectId || null,
      chapterId: data.chapterId || null,
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      description: emptyToNull(data.description),
      youtubeId,
      durationMin: Math.round(data.durationMin || 0),
      thumbnailUrl: emptyToNull(data.thumbnailUrl),
      orderIndex: data.orderIndex || 1,
      isFree: !!data.isFree,
      published: !!data.published,
    };
  }
  if (entity === "pdfs") {
    return {
      courseId: data.courseId,
      subjectId: data.subjectId || null,
      chapterId: data.chapterId || null,
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      description: emptyToNull(data.description),
      fileUrl: data.fileUrl,
      storageKey: null,
      fileSizeKb: Math.round(data.fileSizeKb || 0),
      pageCount: Math.round(data.pageCount || 0),
      isFree: !!data.isFree,
      allowDownload: !!data.allowDownload,
      published: !!data.published,
    };
  }
  if (entity === "quizzes") {
    return {
      courseId: data.courseId,
      subjectId: data.subjectId || null,
      chapterId: data.chapterId || null,
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      description: emptyToNull(data.description),
      difficulty: data.difficulty,
      timeLimitMin: Math.round(data.timeLimitMin),
      passingPercent: Math.round(data.passingPercent),
      isFree: !!data.isFree,
      published: !!data.published,
    };
  }
  if (entity === "notifications") {
    return {
      title: data.title,
      titleMr: emptyToNull(data.titleMr),
      body: emptyToNull(data.body),
      bodyMr: emptyToNull(data.bodyMr),
      kind: data.kind,
      audience: data.audience,
      courseId: data.audience === "COURSE" ? data.courseId || null : null,
    };
  }
  throw new HttpError(400, "Unsupported resource");
}

const extraCols = {
  courses: {
    lectureCount: sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id})::int`,
    pdfCount: sql`(select count(*) from ${pdfs} where ${pdfs.courseId} = ${courses.id})::int`,
    quizCount: sql`(select count(*) from ${quizzes} where ${quizzes.courseId} = ${courses.id})::int`,
    subjectCount: sql`(select count(*) from ${subjects} where ${subjects.courseId} = ${courses.id})::int`,
    studentCount: sql`(select count(*) from ${enrollments} where ${enrollments.courseId} = ${courses.id})::int`,
  },
  quizzes: {
    questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
    attemptCount: sql`(select count(*) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
  },
  subjects: {
    chapterCount: sql`(select count(*) from ${chapters} where ${chapters.subjectId} = ${subjects.id})::int`,
    lectureCount: sql`(select count(*) from ${lectures} where ${lectures.subjectId} = ${subjects.id})::int`,
  },
  chapters: {
    lectureCount: sql`(select count(*) from ${lectures} where ${lectures.chapterId} = ${chapters.id})::int`,
    pdfCount: sql`(select count(*) from ${pdfs} where ${pdfs.chapterId} = ${chapters.id})::int`,
  },
  students: {
    coursesEnrolled: sql`(select count(*) from ${enrollments} where ${enrollments.userId} = ${users.id})::int`,
    lecturesCompleted: sql`(select count(*) from ${lectureProgress} where ${lectureProgress.userId} = ${users.id} and ${lectureProgress.completed})::int`,
    quizzesAttempted: sql`(select count(*) from ${quizAttempts} where ${quizAttempts.userId} = ${users.id})::int`,
    avgScore: sql`(select coalesce(round(avg(${quizAttempts.percent})),0) from ${quizAttempts} where ${quizAttempts.userId} = ${users.id})::int`,
  },
};

export async function listEntity(entity, params) {
  const conf = entityConf(entity);
  const table = conf.table;
  const page = Math.max(1, Number(params.page) || 1);
  const perPage = Math.min(100, Math.max(1, Number(params.perPage) || 10));

  const conditions = [];
  if (entity === "students") conditions.push(inArray(users.role, ["STUDENT", "TEACHER"]));

  if (params.q) {
    const like = `%${params.q}%`;
    conditions.push(or(...conf.searchCols.map((c) => ilike(c, like))));
  }
  if (params.courseId && table.courseId) conditions.push(eq(table.courseId, Number(params.courseId)));
  if (params.subjectId && table.subjectId) conditions.push(eq(table.subjectId, Number(params.subjectId)));
  if (params.chapterId && table.chapterId) conditions.push(eq(table.chapterId, Number(params.chapterId)));
  if (params.status === "published" && table.published) conditions.push(eq(table.published, true));
  if (params.status === "draft" && table.published) conditions.push(eq(table.published, false));
  if (params.access === "free" && table.isFree) conditions.push(eq(table.isFree, true));
  if (params.access === "paid" && table.isFree) conditions.push(eq(table.isFree, false));
  if (params.language && params.language !== "all" && table.language) {
    conditions.push(eq(table.language, params.language));
  }
  if (entity === "students" && params.state === "active") conditions.push(eq(users.status, "ACTIVE"));
  if (entity === "students" && params.state === "inactive") conditions.push(eq(users.status, "INACTIVE"));

  const where = conditions.length ? and(...conditions) : undefined;

  const dir = params.dir === "asc" ? asc : desc;
  const sortCol = conf.sortable?.[params.sort];
  const orderBy = sortCol ? dir(sortCol) : conf.defaultSort;

  const selection = { ...table, ...(extraCols[entity] || {}) };
  if (entity === "students") delete selection.passwordHash;

  let q = db.select(selection).from(table);
  if (where) q = q.where(where);

  const items = await q.orderBy(orderBy).limit(perPage).offset((page - 1) * perPage);

  let countQ = db.select({ n: sql`count(*)::int` }).from(table);
  if (where) countQ = countQ.where(where);
  const [{ n = 0 } = {}] = await countQ;

  // Attach human-readable parent labels for content tables.
  if (["subjects", "chapters", "lectures", "pdfs", "quizzes"].includes(entity)) {
    const courseIds = [...new Set(items.map((i) => i.courseId).filter(Boolean))];
    const subjectIds = [...new Set(items.map((i) => i.subjectId).filter(Boolean))];
    const chapterIds = [...new Set(items.map((i) => i.chapterId).filter(Boolean))];
    const [cRows, sRows, chRows] = await Promise.all([
      courseIds.length
        ? db.select({ id: courses.id, title: courses.title }).from(courses).where(inArray(courses.id, courseIds))
        : [],
      subjectIds.length
        ? db.select({ id: subjects.id, name: subjects.name }).from(subjects).where(inArray(subjects.id, subjectIds))
        : [],
      chapterIds.length
        ? db.select({ id: chapters.id, title: chapters.title }).from(chapters).where(inArray(chapters.id, chapterIds))
        : [],
    ]);
    const cMap = Object.fromEntries(cRows.map((r) => [r.id, r.title]));
    const sMap = Object.fromEntries(sRows.map((r) => [r.id, r.name]));
    const chMap = Object.fromEntries(chRows.map((r) => [r.id, r.title]));
    for (const i of items) {
      i.courseTitle = cMap[i.courseId] || null;
      i.subjectName = sMap[i.subjectId] || null;
      i.chapterTitle = chMap[i.chapterId] || null;
    }
  }

  return {
    items,
    total: Number(n),
    page,
    perPage,
    pages: Math.max(1, Math.ceil(Number(n) / perPage)),
  };
}

export async function getEntity(entity, id) {
  const conf = entityConf(entity);
  const selection = { ...conf.table };
  if (entity === "students") delete selection.passwordHash;
  const [row] = await db.select(selection).from(conf.table).where(eq(conf.table.id, Number(id))).limit(1);
  if (!row) throw new HttpError(404, "Not found");

  if (entity === "quizzes") {
    row.questions = await db
      .select()
      .from(questions)
      .where(eq(questions.quizId, row.id))
      .orderBy(asc(questions.orderIndex), asc(questions.id));
  }
  if (entity === "students") {
    row.enrollments = await db
      .select({
        courseId: enrollments.courseId,
        progressPercent: enrollments.progressPercent,
        title: courses.title,
      })
      .from(enrollments)
      .innerJoin(courses, eq(courses.id, enrollments.courseId))
      .where(eq(enrollments.userId, row.id));
    row.attempts = await db
      .select({
        id: quizAttempts.id,
        percent: quizAttempts.percent,
        passed: quizAttempts.passed,
        createdAt: quizAttempts.createdAt,
        title: quizzes.title,
      })
      .from(quizAttempts)
      .innerJoin(quizzes, eq(quizzes.id, quizAttempts.quizId))
      .where(eq(quizAttempts.userId, row.id))
      .orderBy(desc(quizAttempts.createdAt))
      .limit(10);
  }
  return row;
}

async function syncQuestions(quizId, list = []) {
  await db.delete(questions).where(eq(questions.quizId, quizId));
  if (!list.length) return;
  await db.insert(questions).values(
    list.map((q, i) => ({
      quizId,
      orderIndex: i + 1,
      text: q.text,
      textMr: q.textMr || null,
      options: q.options,
      correctIndex: Number(q.correctIndex) || 0,
      explanation: q.explanation || null,
      marks: Math.round(Number(q.marks) || 1),
      negativeMarks: Math.round(Number(q.negativeMarks) || 0),
    })),
  );
}

export async function createEntity(entity, payload, admin) {
  const conf = entityConf(entity);
  if (conf.readOnly) throw new HttpError(405, "This resource cannot be created here");
  const data = conf.schema.parse(payload);
  const row = toRow(entity, data);
  const [created] = await db.insert(conf.table).values(row).returning();
  if (entity === "quizzes") await syncQuestions(created.id, data.questions);
  await logAudit(admin, "CREATE", entity, created.id, `Created ${entity.slice(0, -1)} "${created.title || created.name}"`);
  return created;
}

export async function updateEntity(entity, id, payload, admin) {
  const conf = entityConf(entity);
  const numericId = Number(id);

  // Lightweight toggles (publish / free-paid / status / reorder)
  if (payload.__action) {
    const action = payload.__action;
    if (entity === "students") {
      if (!["deactivate", "reactivate"].includes(action)) throw new HttpError(400, "Unsupported action");
      const status = action === "deactivate" ? "INACTIVE" : "ACTIVE";
      const [row] = await db.update(users).set({ status }).where(eq(users.id, numericId)).returning();
      await logAudit(admin, action.toUpperCase(), entity, numericId, `${status} student ${row?.name}`);
      const { passwordHash: _drop, ...safe } = row || {};
      return safe;
    }
    const patch = {};
    if (action === "publish") patch.published = true;
    else if (action === "unpublish") patch.published = false;
    else if (action === "makeFree") Object.assign(patch, { isFree: true, ...(entity === "courses" ? { price: 0 } : {}) });
    else if (action === "makePaid") patch.isFree = false;
    else if (action === "reorder") patch.orderIndex = Math.max(1, Number(payload.orderIndex) || 1);
    else throw new HttpError(400, "Unsupported action");

    const [row] = await db.update(conf.table).set(patch).where(eq(conf.table.id, numericId)).returning();
    if (!row) throw new HttpError(404, "Not found");
    await logAudit(admin, action.toUpperCase(), entity, numericId, `${action} on "${row.title || row.name}"`);
    return row;
  }

  if (conf.readOnly) throw new HttpError(405, "This resource is read-only");

  const data = conf.schema.parse(payload);
  const row = toRow(entity, data);
  if (entity === "courses") delete row.slug; // keep the original slug stable
  const [updated] = await db.update(conf.table).set(row).where(eq(conf.table.id, numericId)).returning();
  if (!updated) throw new HttpError(404, "Not found");
  if (entity === "quizzes") await syncQuestions(numericId, data.questions);
  await logAudit(admin, "UPDATE", entity, numericId, `Updated "${updated.title || updated.name}"`);
  return updated;
}

export async function deleteEntity(entity, id, admin) {
  const conf = entityConf(entity);
  if (conf.readOnly) throw new HttpError(405, "This resource cannot be deleted here");
  const numericId = Number(id);

  if (entity === "courses") {
    await db.delete(lectures).where(eq(lectures.courseId, numericId));
    await db.delete(pdfs).where(eq(pdfs.courseId, numericId));
    const qs = await db.select({ id: quizzes.id }).from(quizzes).where(eq(quizzes.courseId, numericId));
    if (qs.length) await db.delete(questions).where(inArray(questions.quizId, qs.map((q) => q.id)));
    await db.delete(quizzes).where(eq(quizzes.courseId, numericId));
    await db.delete(chapters).where(eq(chapters.courseId, numericId));
    await db.delete(subjects).where(eq(subjects.courseId, numericId));
    await db.delete(enrollments).where(eq(enrollments.courseId, numericId));
  }
  if (entity === "subjects") {
    await db.delete(lectures).where(eq(lectures.subjectId, numericId));
    await db.delete(pdfs).where(eq(pdfs.subjectId, numericId));
    await db.delete(chapters).where(eq(chapters.subjectId, numericId));
  }
  if (entity === "chapters") {
    await db.delete(lectures).where(eq(lectures.chapterId, numericId));
    await db.delete(pdfs).where(eq(pdfs.chapterId, numericId));
  }
  if (entity === "quizzes") {
    await db.delete(questions).where(eq(questions.quizId, numericId));
    await db.delete(quizAttempts).where(eq(quizAttempts.quizId, numericId));
  }
  if (entity === "lectures") {
    await db.delete(lectureProgress).where(eq(lectureProgress.lectureId, numericId));
  }

  const [row] = await db.delete(conf.table).where(eq(conf.table.id, numericId)).returning();
  if (!row) throw new HttpError(404, "Not found");
  await logAudit(admin, "DELETE", entity, numericId, `Deleted "${row.title || row.name}"`);
  return row;
}

export async function duplicateEntity(entity, id, admin) {
  const conf = entityConf(entity);
  if (!["courses", "quizzes"].includes(entity)) throw new HttpError(400, "Duplication not supported");
  const [row] = await db.select().from(conf.table).where(eq(conf.table.id, Number(id))).limit(1);
  if (!row) throw new HttpError(404, "Not found");

  const { id: _omit, createdAt: _omitAt, ...rest } = row;
  const copy = {
    ...rest,
    title: `${row.title} (Copy)`,
    published: false,
    ...(entity === "courses" ? { slug: `${slugify(row.title)}-copy-${Math.random().toString(36).slice(2, 6)}` } : {}),
  };
  const [created] = await db.insert(conf.table).values(copy).returning();

  if (entity === "quizzes") {
    const qs = await db.select().from(questions).where(eq(questions.quizId, row.id));
    if (qs.length) {
      await db.insert(questions).values(
        qs.map(({ id: _qid, ...q }) => ({ ...q, quizId: created.id })),
      );
    }
  }
  if (entity === "courses") {
    const subs = await db.select().from(subjects).where(eq(subjects.courseId, row.id));
    for (const s of subs) {
      const { id: sid, ...sRest } = s;
      const [newSub] = await db.insert(subjects).values({ ...sRest, courseId: created.id }).returning();
      const chs = await db.select().from(chapters).where(eq(chapters.subjectId, sid));
      for (const c of chs) {
        const { id: cid, ...cRest } = c;
        const [newCh] = await db
          .insert(chapters)
          .values({ ...cRest, courseId: created.id, subjectId: newSub.id })
          .returning();
        const lecs = await db.select().from(lectures).where(eq(lectures.chapterId, cid));
        if (lecs.length) {
          await db.insert(lectures).values(
            lecs.map(({ id: _lid, ...l }) => ({
              ...l,
              courseId: created.id,
              subjectId: newSub.id,
              chapterId: newCh.id,
              published: false,
            })),
          );
        }
        const docs = await db.select().from(pdfs).where(eq(pdfs.chapterId, cid));
        if (docs.length) {
          await db.insert(pdfs).values(
            docs.map(({ id: _pid, ...p }) => ({
              ...p,
              courseId: created.id,
              subjectId: newSub.id,
              chapterId: newCh.id,
              published: false,
            })),
          );
        }
      }
    }
  }

  await logAudit(admin, "DUPLICATE", entity, created.id, `Duplicated from #${id}`);
  return created;
}

export async function bulkEntity(entity, action, ids, admin) {
  const conf = entityConf(entity);
  const list = (ids || []).map(Number).filter(Number.isFinite);
  if (!list.length) throw new HttpError(400, "No items selected");

  if (action === "delete") {
    for (const id of list) await deleteEntity(entity, id, admin);
    return { affected: list.length };
  }
  if (!["publish", "unpublish", "makeFree", "makePaid"].includes(action)) {
    throw new HttpError(400, "Unsupported bulk action");
  }
  const patch =
    action === "publish"
      ? { published: true }
      : action === "unpublish"
        ? { published: false }
        : action === "makeFree"
          ? { isFree: true }
          : { isFree: false };

  await db.update(conf.table).set(patch).where(inArray(conf.table.id, list));
  await logAudit(admin, `BULK_${action.toUpperCase()}`, entity, list.join(","), `${list.length} items`);
  return { affected: list.length };
}
