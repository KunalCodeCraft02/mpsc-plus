import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Users                                                              */
/* ------------------------------------------------------------------ */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 190 }).notNull(),
    mobile: varchar("mobile", { length: 20 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 20 }).notNull().default("STUDENT"), // STUDENT | ADMIN | TEACHER
    language: varchar("language", { length: 5 }).notNull().default("en"),
    avatarUrl: text("avatar_url"),
    status: varchar("status", { length: 20 }).notNull().default("ACTIVE"),
    xp: integer("xp").notNull().default(0),
    streakCurrent: integer("streak_current").notNull().default(0),
    streakLongest: integer("streak_longest").notNull().default(0),
    lastStudyDate: varchar("last_study_date", { length: 10 }),
    termsVersion: varchar("terms_version", { length: 20 }),
    privacyVersion: varchar("privacy_version", { length: 20 }),
    acceptedAt: timestamp("accepted_at", { withTimezone: true }),
    platform: varchar("platform", { length: 20 }).default("web"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("users_email_uq").on(t.email),
    uniqueIndex("users_mobile_uq").on(t.mobile),
    index("users_xp_idx").on(t.xp),
  ],
);

/* ------------------------------------------------------------------ */
/* Catalog                                                            */
/* ------------------------------------------------------------------ */
export const courses = pgTable(
  "courses",
  {
    id: serial("id").primaryKey(),
    title: varchar("title", { length: 200 }).notNull(),
    titleMr: varchar("title_mr", { length: 200 }),
    slug: varchar("slug", { length: 220 }).notNull(),
    description: text("description"),
    descriptionMr: text("description_mr"),
    thumbnailUrl: text("thumbnail_url"),
    instructor: varchar("instructor", { length: 160 }),
    category: varchar("category", { length: 80 }),
    language: varchar("language", { length: 20 }).default("Marathi"),
    isFree: boolean("is_free").notNull().default(true),
    price: integer("price").notNull().default(0),
    currency: varchar("currency", { length: 8 }).notNull().default("INR"),
    validityDays: integer("validity_days").default(365),
    published: boolean("published").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("courses_slug_uq").on(t.slug),
    index("courses_pub_idx").on(t.published),
  ],
);

export const subjects = pgTable(
  "subjects",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id").notNull(),
    name: varchar("name", { length: 200 }).notNull(),
    nameMr: varchar("name_mr", { length: 200 }),
    description: text("description"),
    orderIndex: integer("order_index").notNull().default(1),
  },
  (t) => [index("subjects_course_idx").on(t.courseId)],
);

export const chapters = pgTable(
  "chapters",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id").notNull(),
    subjectId: integer("subject_id").notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    titleMr: varchar("title_mr", { length: 200 }),
    description: text("description"),
    orderIndex: integer("order_index").notNull().default(1),
  },
  (t) => [index("chapters_subject_idx").on(t.subjectId)],
);

export const lectures = pgTable(
  "lectures",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id").notNull(),
    subjectId: integer("subject_id"),
    chapterId: integer("chapter_id"),
    title: varchar("title", { length: 220 }).notNull(),
    titleMr: varchar("title_mr", { length: 220 }),
    description: text("description"),
    youtubeId: varchar("youtube_id", { length: 40 }),
    durationMin: integer("duration_min").default(0),
    thumbnailUrl: text("thumbnail_url"),
    orderIndex: integer("order_index").notNull().default(1),
    isFree: boolean("is_free").notNull().default(false),
    published: boolean("published").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("lectures_course_idx").on(t.courseId),
    index("lectures_chapter_idx").on(t.chapterId),
  ],
);

export const pdfs = pgTable(
  "pdfs",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id").notNull(),
    subjectId: integer("subject_id"),
    chapterId: integer("chapter_id"),
    title: varchar("title", { length: 220 }).notNull(),
    titleMr: varchar("title_mr", { length: 220 }),
    description: text("description"),
    fileUrl: text("file_url"),
    storageKey: text("storage_key"),
    fileSizeKb: integer("file_size_kb").default(0),
    pageCount: integer("page_count").default(0),
    isFree: boolean("is_free").notNull().default(false),
    allowDownload: boolean("allow_download").notNull().default(true),
    published: boolean("published").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("pdfs_course_idx").on(t.courseId)],
);

export const quizzes = pgTable(
  "quizzes",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id").notNull(),
    subjectId: integer("subject_id"),
    chapterId: integer("chapter_id"),
    title: varchar("title", { length: 220 }).notNull(),
    titleMr: varchar("title_mr", { length: 220 }),
    description: text("description"),
    difficulty: varchar("difficulty", { length: 12 }).notNull().default("medium"),
    timeLimitMin: integer("time_limit_min").notNull().default(15),
    passingPercent: integer("passing_percent").notNull().default(40),
    isFree: boolean("is_free").notNull().default(true),
    published: boolean("published").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("quizzes_course_idx").on(t.courseId)],
);

export const questions = pgTable(
  "questions",
  {
    id: serial("id").primaryKey(),
    quizId: integer("quiz_id").notNull(),
    orderIndex: integer("order_index").notNull().default(1),
    text: text("text").notNull(),
    textMr: text("text_mr"),
    options: jsonb("options").notNull(),
    optionsMr: jsonb("options_mr"),
    correctIndex: integer("correct_index").notNull().default(0),
    explanation: text("explanation"),
    marks: integer("marks").notNull().default(1),
    negativeMarks: integer("negative_marks").notNull().default(0),
  },
  (t) => [index("questions_quiz_idx").on(t.quizId)],
);

/* ------------------------------------------------------------------ */
/* Learning activity                                                  */
/* ------------------------------------------------------------------ */
export const enrollments = pgTable(
  "enrollments",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    courseId: integer("course_id").notNull(),
    progressPercent: integer("progress_percent").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("enroll_uq").on(t.userId, t.courseId)],
);

export const lectureProgress = pgTable(
  "lecture_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    courseId: integer("course_id").notNull(),
    lectureId: integer("lecture_id").notNull(),
    positionSec: integer("position_sec").notNull().default(0),
    percent: integer("percent").notNull().default(0),
    completed: boolean("completed").notNull().default(false),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("lecture_progress_uq").on(t.userId, t.lectureId)],
);

export const quizAttempts = pgTable(
  "quiz_attempts",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    quizId: integer("quiz_id").notNull(),
    courseId: integer("course_id"),
    score: integer("score").notNull().default(0),
    totalMarks: integer("total_marks").notNull().default(0),
    percent: integer("percent").notNull().default(0),
    correct: integer("correct").notNull().default(0),
    incorrect: integer("incorrect").notNull().default(0),
    unanswered: integer("unanswered").notNull().default(0),
    timeTakenSec: integer("time_taken_sec").notNull().default(0),
    passed: boolean("passed").notNull().default(false),
    answers: jsonb("answers"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("attempts_user_idx").on(t.userId, t.quizId)],
);

/* ------------------------------------------------------------------ */
/* Gamification                                                       */
/* ------------------------------------------------------------------ */
export const xpEvents = pgTable(
  "xp_events",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    kind: varchar("kind", { length: 40 }).notNull(),
    refId: varchar("ref_id", { length: 60 }).notNull().default("0"),
    amount: integer("amount").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("xp_dedupe_uq").on(t.userId, t.kind, t.refId),
    index("xp_user_idx").on(t.userId),
  ],
);

export const userBadges = pgTable(
  "user_badges",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    code: varchar("code", { length: 40 }).notNull(),
    earnedAt: timestamp("earned_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("badge_uq").on(t.userId, t.code)],
);

/* ------------------------------------------------------------------ */
/* Platform                                                           */
/* ------------------------------------------------------------------ */
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  titleMr: varchar("title_mr", { length: 200 }),
  body: text("body"),
  bodyMr: text("body_mr"),
  kind: varchar("kind", { length: 30 }).notNull().default("update"),
  audience: varchar("audience", { length: 30 }).notNull().default("ALL"),
  courseId: integer("course_id"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id"),
  adminName: varchar("admin_name", { length: 160 }),
  action: varchar("action", { length: 40 }).notNull(),
  entity: varchar("entity", { length: 40 }).notNull(),
  entityId: varchar("entity_id", { length: 40 }),
  detail: text("detail"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const searchQueries = pgTable(
  "search_queries",
  {
    id: serial("id").primaryKey(),
    q: varchar("q", { length: 160 }).notNull(),
    hits: integer("hits").notNull().default(1),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("search_q_uq").on(t.q)],
);

export const appSettings = pgTable("app_settings", {
  key: varchar("key", { length: 60 }).primaryKey(),
  value: jsonb("value").notNull(),
});
