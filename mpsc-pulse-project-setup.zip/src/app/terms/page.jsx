"use client";

import { LegalPage } from "@/components/legal/LegalPage";

export default function TermsPage() {
  return <LegalPage docKey="terms" />;
}
