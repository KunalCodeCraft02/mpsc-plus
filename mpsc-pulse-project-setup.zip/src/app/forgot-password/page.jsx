"use client";

import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { KeyRound, Mail, ArrowLeft, MailCheck } from "lucide-react";
import { AuthShell } from "@/components/layout/AuthShell";
import { useI18n } from "@/context/I18nContext";
import { Button, Input, Alert } from "@/components/ui";
import { forgotSchema } from "@/server/validation";

export default function ForgotPasswordPage() {
  const { t } = useI18n();
  const [sent, setSent] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(forgotSchema), defaultValues: { email: "" } });

  const onSubmit = async () => {
    // Always show the same neutral confirmation so account existence is never revealed.
    await new Promise((r) => setTimeout(r, 700));
    setSent(true);
  };

  return (
    <AuthShell>
      <div className="animate-fade-up">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
          {sent ? (
            <MailCheck className="h-5.5 w-5.5" style={{ height: 22, width: 22 }} />
          ) : (
            <KeyRound className="h-5.5 w-5.5" style={{ height: 22, width: 22 }} />
          )}
        </span>
        <h1 className="mt-5 text-2xl font-extrabold tracking-tight text-ink">{t("auth.forgotTitle")}</h1>
        <p className="mt-1.5 text-[14px] leading-relaxed text-muted">{t("auth.forgotSub")}</p>

        {sent ? (
          <Alert tone="success" className="mt-6">
            {t("auth.forgotSent")}
          </Alert>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
            <Input
              label={t("auth.email")}
              placeholder="you@example.com"
              type="email"
              leftIcon={Mail}
              error={errors.email?.message}
              {...register("email")}
            />
            <Button type="submit" size="lg" fullWidth loading={isSubmitting}>
              {t("auth.sendLink")}
            </Button>
          </form>
        )}

        <Link
          href="/login"
          className="mt-6 inline-flex items-center gap-1.5 text-[13.5px] font-bold text-brand-600 hover:underline"
        >
          <ArrowLeft className="h-4 w-4" />
          {t("auth.backToLogin")}
        </Link>
      </div>
    </AuthShell>
  );
}
