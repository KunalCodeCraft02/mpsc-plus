import { and, eq, ilike, or, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { pdfs, courses, chapters, enrollments } from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { currentUser } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const q = query(request);
  const page = Math.max(1, num(q.page, 1));
  const perPage = Math.min(60, Math.max(1, num(q.perPage, 24)));

  const conditions = [eq(pdfs.published, true), eq(courses.published, true)];
  if (q.q) {
    conditions.push(or(ilike(pdfs.title, `%${q.q}%`), ilike(pdfs.titleMr, `%${q.q}%`)));
  }
  if (q.courseId) conditions.push(eq(pdfs.courseId, num(q.courseId)));
  if (q.access === "free") conditions.push(eq(pdfs.isFree, true));
  if (q.access === "paid") conditions.push(eq(pdfs.isFree, false));

  const where = and(...conditions);

  const rows = await db
    .select({
      id: pdfs.id,
      title: pdfs.title,
      titleMr: pdfs.titleMr,
      description: pdfs.description,
      pageCount: pdfs.pageCount,
      fileSizeKb: pdfs.fileSizeKb,
      isFree: pdfs.isFree,
      allowDownload: pdfs.allowDownload,
      courseId: pdfs.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
      courseIsFree: courses.isFree,
      chapterTitle: chapters.title,
    })
    .from(pdfs)
    .innerJoin(courses, eq(courses.id, pdfs.courseId))
    .leftJoin(chapters, eq(chapters.id, pdfs.chapterId))
    .where(where)
    .orderBy(desc(pdfs.createdAt))
    .limit(perPage)
    .offset((page - 1) * perPage);

  const [{ n = 0 } = {}] = await db
    .select({ n: sql`count(*)::int` })
    .from(pdfs)
    .innerJoin(courses, eq(courses.id, pdfs.courseId))
    .where(where);

  const user = await currentUser(request);
  let enrolled = new Set();
  if (user) {
    const rowsE = await db
      .select({ courseId: enrollments.courseId })
      .from(enrollments)
      .where(eq(enrollments.userId, user.id));
    enrolled = new Set(rowsE.map((r) => r.courseId));
  }

  return ok({
    items: rows.map((r) => ({
      ...r,
      locked: !(r.isFree || r.courseIsFree || enrolled.has(r.courseId) || user?.role === "ADMIN"),
    })),
    total: Number(n),
    page,
    perPage,
    pages: Math.max(1, Math.ceil(Number(n) / perPage)),
  });
});
