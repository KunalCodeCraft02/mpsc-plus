import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { pdfs, courses, chapters, subjects, enrollments } from "@/db/schema";
import { handler, ok, fail } from "@/server/http";
import { currentUser } from "@/server/auth";
import { awardXp, touchStreak } from "@/server/gamification";

export const dynamic = "force-dynamic";

export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const pdfId = Number(id);
  if (!Number.isFinite(pdfId)) return fail(400, "Invalid material id");

  const [pdf] = await db.select().from(pdfs).where(eq(pdfs.id, pdfId)).limit(1);
  if (!pdf || !pdf.published) return fail(404, "Study material not found");

  const [course] = await db.select().from(courses).where(eq(courses.id, pdf.courseId)).limit(1);
  const user = await currentUser(request);

  let enrollment = null;
  if (user) {
    const [e] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, pdf.courseId)))
      .limit(1);
    enrollment = e || null;
  }

  const hasAccess = course?.isFree || pdf.isFree || !!enrollment || user?.role === "ADMIN";
  if (!hasAccess) {
    return fail(403, "Enrol in this course to open this material.", {
      locked: true,
      courseId: pdf.courseId,
    });
  }

  const [chapter] = pdf.chapterId
    ? await db.select().from(chapters).where(eq(chapters.id, pdf.chapterId)).limit(1)
    : [null];
  const [subject] = pdf.subjectId
    ? await db.select().from(subjects).where(eq(subjects.id, pdf.subjectId)).limit(1)
    : [null];

  if (user && user.role === "STUDENT") {
    await touchStreak(user.id);
    await awardXp(user.id, "pdf_read", `pdf-${pdf.id}`);
  }

  return ok({
    pdf: {
      ...pdf,
      // Download availability is enforced here; the client only hides the button.
      downloadUrl: pdf.allowDownload ? pdf.fileUrl : null,
    },
    course: course ? { id: course.id, title: course.title, titleMr: course.titleMr } : null,
    chapter,
    subject,
  });
});
