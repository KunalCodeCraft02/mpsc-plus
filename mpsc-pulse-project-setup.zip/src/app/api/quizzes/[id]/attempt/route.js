import { and, eq, asc, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { quizzes, questions, courses, enrollments, quizAttempts } from "@/db/schema";
import { handler, body, ok, fail } from "@/server/http";
import { requireAuth } from "@/server/auth";
import { attemptSchema } from "@/server/validation";
import { awardXp, touchStreak, recomputeBadges } from "@/server/gamification";
import { XP_RULES } from "@/lib/config";

/**
 * Backend-only evaluation. The client submits selected option indexes; the
 * score, marks and pass/fail are computed here from the stored answer key.
 */
export const POST = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const quizId = Number(id);
  if (!Number.isFinite(quizId)) return fail(400, "Invalid test id");

  const user = await requireAuth(request);
  const data = attemptSchema.parse(await body(request));

  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
  if (!quiz || !quiz.published) return fail(404, "Test not found");

  const [course] = await db.select().from(courses).where(eq(courses.id, quiz.courseId)).limit(1);
  const [enrollment] = await db
    .select()
    .from(enrollments)
    .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, quiz.courseId)))
    .limit(1);

  const hasAccess = quiz.isFree || course?.isFree || !!enrollment || user.role === "ADMIN";
  if (!hasAccess) return fail(403, "Enrol in this course to attempt this test.");

  // Throttle accidental duplicate submissions (double-tap / retry storms).
  const [recent] = await db
    .select({ id: quizAttempts.id, createdAt: quizAttempts.createdAt })
    .from(quizAttempts)
    .where(and(eq(quizAttempts.userId, user.id), eq(quizAttempts.quizId, quizId)))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(1);

  if (recent && Date.now() - new Date(recent.createdAt).getTime() < 8000) {
    return ok({ attemptId: recent.id, duplicate: true });
  }

  const key = await db
    .select()
    .from(questions)
    .where(eq(questions.quizId, quizId))
    .orderBy(asc(questions.orderIndex), asc(questions.id));

  if (!key.length) return fail(409, "This test has no questions yet.");

  let score = 0;
  let totalMarks = 0;
  let correct = 0;
  let incorrect = 0;
  let unanswered = 0;
  const review = [];

  for (const q of key) {
    const marks = Number(q.marks || 0);
    const neg = Number(q.negativeMarks || 0);
    totalMarks += marks;
    const raw = data.answers[String(q.id)];
    const selected = raw == null || raw < 0 ? null : Number(raw);

    let state = "unanswered";
    if (selected == null) {
      unanswered += 1;
    } else if (selected === q.correctIndex) {
      score += marks;
      correct += 1;
      state = "correct";
    } else {
      score -= neg;
      incorrect += 1;
      state = "incorrect";
    }

    review.push({
      questionId: q.id,
      orderIndex: q.orderIndex,
      text: q.text,
      textMr: q.textMr,
      options: q.options,
      optionsMr: q.optionsMr,
      correctIndex: q.correctIndex,
      selectedIndex: selected,
      explanation: q.explanation,
      marks,
      negativeMarks: neg,
      state,
    });
  }

  score = Math.max(0, score);
  const percent = totalMarks ? Math.round((score / totalMarks) * 100) : 0;
  const passed = percent >= Number(quiz.passingPercent || 0);
  const timeCap = Number(quiz.timeLimitMin || 0) * 60 + 120;
  const timeTakenSec = Math.min(Math.round(data.timeTakenSec), timeCap || 999999);

  const [attempt] = await db
    .insert(quizAttempts)
    .values({
      userId: user.id,
      quizId,
      courseId: quiz.courseId,
      score,
      totalMarks,
      percent,
      correct,
      incorrect,
      unanswered,
      timeTakenSec,
      passed,
      answers: { selected: data.answers, review },
    })
    .returning();

  /* XP — derived server-side from the verified result */
  let xpEarned = 0;
  xpEarned += await awardXp(user.id, "quiz_attempt", `quiz-${quizId}-${attempt.id}`);
  if (correct > 0) {
    xpEarned += await awardXp(
      user.id,
      "quiz_correct_answer",
      `quiz-correct-${attempt.id}`,
      correct * XP_RULES.quiz_correct_answer,
    );
  }
  if (percent >= 80) {
    xpEarned += await awardXp(user.id, "quiz_high_score_bonus", `quiz-high-${attempt.id}`);
  }
  if (percent >= 100) {
    xpEarned += await awardXp(user.id, "quiz_perfect_bonus", `quiz-perfect-${attempt.id}`);
  }
  const streak = await touchStreak(user.id);
  xpEarned += streak.bonus;
  const badges = await recomputeBadges(user.id);

  await db
    .insert(enrollments)
    .values({ userId: user.id, courseId: quiz.courseId })
    .onConflictDoNothing();

  return ok({ attemptId: attempt.id, xpEarned, badges, streak });
});

export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const user = await requireAuth(request);
  const rows = await db
    .select({
      id: quizAttempts.id,
      score: quizAttempts.score,
      totalMarks: quizAttempts.totalMarks,
      percent: quizAttempts.percent,
      passed: quizAttempts.passed,
      createdAt: quizAttempts.createdAt,
    })
    .from(quizAttempts)
    .where(and(eq(quizAttempts.userId, user.id), eq(quizAttempts.quizId, Number(id))))
    .orderBy(desc(quizAttempts.createdAt));
  const [agg] = await db
    .select({ best: sql`coalesce(max(${quizAttempts.percent}),0)::int` })
    .from(quizAttempts)
    .where(and(eq(quizAttempts.userId, user.id), eq(quizAttempts.quizId, Number(id))));
  return ok({ attempts: rows, best: Number(agg?.best || 0) });
});
