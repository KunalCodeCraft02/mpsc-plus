import { and, eq, asc, desc } from "drizzle-orm";
import { db } from "@/db";
import { quizzes, questions, courses, enrollments, quizAttempts } from "@/db/schema";
import { handler, ok, fail } from "@/server/http";
import { currentUser } from "@/server/auth";

export const dynamic = "force-dynamic";

/**
 * Returns the quiz paper WITHOUT correct answers or explanations so the
 * answer key can never be scraped from the network response.
 */
export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const quizId = Number(id);
  if (!Number.isFinite(quizId)) return fail(400, "Invalid test id");

  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
  if (!quiz || !quiz.published) return fail(404, "Test not found");

  const user = await currentUser(request);
  const [course] = await db.select().from(courses).where(eq(courses.id, quiz.courseId)).limit(1);

  let enrollment = null;
  if (user) {
    const [e] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, quiz.courseId)))
      .limit(1);
    enrollment = e || null;
  }

  const hasAccess = quiz.isFree || course?.isFree || !!enrollment || user?.role === "ADMIN";
  if (!hasAccess) {
    return fail(403, "Enrol in this course to attempt this test.", {
      locked: true,
      courseId: quiz.courseId,
    });
  }

  const rows = await db
    .select({
      id: questions.id,
      orderIndex: questions.orderIndex,
      text: questions.text,
      textMr: questions.textMr,
      options: questions.options,
      optionsMr: questions.optionsMr,
      marks: questions.marks,
      negativeMarks: questions.negativeMarks,
    })
    .from(questions)
    .where(eq(questions.quizId, quizId))
    .orderBy(asc(questions.orderIndex), asc(questions.id));

  let lastAttempt = null;
  if (user) {
    const [a] = await db
      .select()
      .from(quizAttempts)
      .where(and(eq(quizAttempts.userId, user.id), eq(quizAttempts.quizId, quizId)))
      .orderBy(desc(quizAttempts.createdAt))
      .limit(1);
    lastAttempt = a || null;
  }

  return ok({
    quiz: {
      ...quiz,
      courseTitle: course?.title,
      courseTitleMr: course?.titleMr,
      questionCount: rows.length,
      totalMarks: rows.reduce((s, r) => s + Number(r.marks || 0), 0),
    },
    questions: rows,
    lastAttempt,
  });
});
