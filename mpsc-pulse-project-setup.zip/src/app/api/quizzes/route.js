import { and, eq, ilike, or, sql, desc } from "drizzle-orm";
import { db } from "@/db";
import { quizzes, questions, courses, quizAttempts } from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { currentUser } from "@/server/auth";
import { ensureSeeded } from "@/server/seed";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  try {
    await ensureSeeded();
  } catch {
    /* ignore */
  }
  const q = query(request);
  const page = Math.max(1, num(q.page, 1));
  const perPage = Math.min(50, Math.max(1, num(q.perPage, 20)));

  const conditions = [eq(quizzes.published, true)];
  if (q.q) {
    conditions.push(or(ilike(quizzes.title, `%${q.q}%`), ilike(quizzes.titleMr, `%${q.q}%`)));
  }
  if (q.courseId) conditions.push(eq(quizzes.courseId, num(q.courseId)));
  if (q.difficulty && q.difficulty !== "all") conditions.push(eq(quizzes.difficulty, q.difficulty));
  if (q.access === "free") conditions.push(eq(quizzes.isFree, true));
  if (q.access === "paid") conditions.push(eq(quizzes.isFree, false));

  const where = and(...conditions);

  const rows = await db
    .select({
      id: quizzes.id,
      title: quizzes.title,
      titleMr: quizzes.titleMr,
      description: quizzes.description,
      difficulty: quizzes.difficulty,
      timeLimitMin: quizzes.timeLimitMin,
      passingPercent: quizzes.passingPercent,
      isFree: quizzes.isFree,
      courseId: quizzes.courseId,
      createdAt: quizzes.createdAt,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
      questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
      totalMarks: sql`(select coalesce(sum(${questions.marks}),0) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
    })
    .from(quizzes)
    .leftJoin(courses, eq(courses.id, quizzes.courseId))
    .where(where)
    .orderBy(desc(quizzes.createdAt))
    .limit(perPage)
    .offset((page - 1) * perPage);

  const user = await currentUser(request);
  let attemptsByQuiz = {};
  if (user) {
    const attempts = await db
      .select()
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, user.id))
      .orderBy(desc(quizAttempts.createdAt));
    for (const a of attempts) {
      if (!attemptsByQuiz[a.quizId]) attemptsByQuiz[a.quizId] = a;
    }
  }

  const [{ n = 0 } = {}] = await db.select({ n: sql`count(*)::int` }).from(quizzes).where(where);

  return ok({
    items: rows.map((r) => ({ ...r, attempt: attemptsByQuiz[r.id] || null })),
    total: Number(n),
    page,
    perPage,
    pages: Math.max(1, Math.ceil(Number(n) / perPage)),
  });
});
