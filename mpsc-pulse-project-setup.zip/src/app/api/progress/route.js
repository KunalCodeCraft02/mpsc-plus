import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { lectures, lectureProgress, enrollments, courses } from "@/db/schema";
import { handler, body, ok, fail } from "@/server/http";
import { requireAuth } from "@/server/auth";
import { awardXp, touchStreak, recomputeBadges, grantBadge } from "@/server/gamification";
import { progressSchema } from "@/server/validation";

/**
 * Lecture progress + XP. XP is derived here from a verified activity — the
 * client can never post an XP amount.
 */
export const POST = handler(async (request) => {
  const user = await requireAuth(request);
  const data = progressSchema.parse(await body(request));

  const [lecture] = await db
    .select()
    .from(lectures)
    .where(eq(lectures.id, data.lectureId))
    .limit(1);
  if (!lecture || !lecture.published) return fail(404, "Lecture not found");

  const [course] = await db.select().from(courses).where(eq(courses.id, lecture.courseId)).limit(1);
  const [enrollment] = await db
    .select()
    .from(enrollments)
    .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, lecture.courseId)))
    .limit(1);

  if (!enrollment && !course?.isFree && !lecture.isFree) {
    return fail(403, "Enrol in this course first.");
  }

  if (!enrollment && (course?.isFree || lecture.isFree)) {
    await db
      .insert(enrollments)
      .values({ userId: user.id, courseId: lecture.courseId })
      .onConflictDoNothing();
  }

  const completed = !!data.completed || data.percent >= 95;

  const [row] = await db
    .insert(lectureProgress)
    .values({
      userId: user.id,
      courseId: lecture.courseId,
      lectureId: lecture.id,
      positionSec: Math.round(data.positionSec),
      percent: Math.round(data.percent),
      completed,
      completedAt: completed ? new Date() : null,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: [lectureProgress.userId, lectureProgress.lectureId],
      set: {
        positionSec: sql`greatest(${lectureProgress.positionSec}, ${Math.round(data.positionSec)})`,
        percent: sql`greatest(${lectureProgress.percent}, ${Math.round(data.percent)})`,
        completed: sql`${lectureProgress.completed} or ${completed}`,
        completedAt: sql`coalesce(${lectureProgress.completedAt}, ${completed ? new Date().toISOString() : null})`,
        updatedAt: new Date(),
      },
    })
    .returning();

  let xpEarned = 0;
  const badges = [];

  if (row.completed) {
    xpEarned += await awardXp(user.id, "lecture_complete", `lecture-${lecture.id}`);
    const streak = await touchStreak(user.id);
    xpEarned += streak.bonus;

    // Chapter completion bonus
    if (lecture.chapterId) {
      const chapterRes = await db.execute(sql`
        select count(*)::int as total,
               count(lp.id) filter (where lp.completed)::int as done
        from lectures l
        left join lecture_progress lp
          on lp.lecture_id = l.id and lp.user_id = ${user.id}
        where l.chapter_id = ${lecture.chapterId} and l.published
      `);
      const chapterStats = chapterRes.rows?.[0];
      if (
        Number(chapterStats?.total) > 0 &&
        Number(chapterStats.total) === Number(chapterStats.done)
      ) {
        xpEarned += await awardXp(user.id, "chapter_complete_bonus", `chapter-${lecture.chapterId}`);
      }
    }

    // Course progress + completion bonus
    const courseRes = await db.execute(sql`
      select count(*)::int as total,
             count(lp.id) filter (where lp.completed)::int as done
      from lectures l
      left join lecture_progress lp
        on lp.lecture_id = l.id and lp.user_id = ${user.id}
      where l.course_id = ${lecture.courseId} and l.published
    `);
    const courseStats = courseRes.rows?.[0];

    const total = Number(courseStats?.total || 0);
    const done = Number(courseStats?.done || 0);
    const percent = total ? Math.round((done / total) * 100) : 0;

    await db
      .update(enrollments)
      .set({ progressPercent: percent })
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, lecture.courseId)));

    if (percent >= 100) {
      xpEarned += await awardXp(user.id, "course_complete_bonus", `course-${lecture.courseId}`);
      const b = await grantBadge(user.id, "course_completed");
      if (b) badges.push(b);
    }

    badges.push(...(await recomputeBadges(user.id)));
  }

  return ok({ progress: row, xpEarned, badges });
});
