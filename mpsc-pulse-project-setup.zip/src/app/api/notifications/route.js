import { desc, eq, or, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications, enrollments } from "@/db/schema";
import { handler, ok } from "@/server/http";
import { currentUser } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const user = await currentUser(request);

  if (!user) {
    const rows = await db
      .select()
      .from(notifications)
      .where(eq(notifications.audience, "ALL"))
      .orderBy(desc(notifications.createdAt))
      .limit(20);
    return ok({ items: rows });
  }

  const myCourses = await db
    .select({ courseId: enrollments.courseId })
    .from(enrollments)
    .where(eq(enrollments.userId, user.id));

  const ids = myCourses.map((c) => c.courseId);

  const rows = await db
    .select()
    .from(notifications)
    .where(
      ids.length
        ? or(eq(notifications.audience, "ALL"), inArray(notifications.courseId, ids))
        : eq(notifications.audience, "ALL"),
    )
    .orderBy(desc(notifications.createdAt))
    .limit(40);

  const [{ n = 0 } = {}] = await db.select({ n: sql`count(*)::int` }).from(notifications);

  return ok({ items: rows, total: Number(n) });
});
