import { eq, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { quizAttempts, quizzes, userBadges, enrollments, courses, lectures, lectureProgress } from "@/db/schema";
import { handler, ok } from "@/server/http";
import { requireAuth } from "@/server/auth";
import { levelFor } from "@/lib/config";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const user = await requireAuth(request);

  const weekly = await db.execute(sql`
    with days as (
      select generate_series(current_date - interval '6 days', current_date, interval '1 day')::date as d
    )
    select days.d as day,
      (select count(*) from lecture_progress lp
        where lp.user_id = ${user.id} and lp.completed and lp.completed_at::date = days.d)::int as lectures,
      (select count(*) from quiz_attempts qa
        where qa.user_id = ${user.id} and qa.created_at::date = days.d)::int as quizzes,
      (select coalesce(sum(xe.amount),0) from xp_events xe
        where xe.user_id = ${user.id} and xe.created_at::date = days.d)::int as xp,
      (select coalesce(sum(l.duration_min),0) from lecture_progress lp
        join lectures l on l.id = lp.lecture_id
        where lp.user_id = ${user.id} and lp.completed and lp.completed_at::date = days.d)::int as minutes
    from days order by days.d
  `);

  const scores = await db
    .select({
      id: quizAttempts.id,
      percent: quizAttempts.percent,
      createdAt: quizAttempts.createdAt,
      title: quizzes.title,
      titleMr: quizzes.titleMr,
      passed: quizAttempts.passed,
      score: quizAttempts.score,
      totalMarks: quizAttempts.totalMarks,
    })
    .from(quizAttempts)
    .innerJoin(quizzes, eq(quizzes.id, quizAttempts.quizId))
    .where(eq(quizAttempts.userId, user.id))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(10);

  const courseProgress = await db
    .select({
      courseId: enrollments.courseId,
      title: courses.title,
      titleMr: courses.titleMr,
      progressPercent: enrollments.progressPercent,
      lectureCount: sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id} and ${lectures.published})::int`,
      completedCount: sql`(select count(*) from ${lectureProgress} where ${lectureProgress.courseId} = ${courses.id} and ${lectureProgress.userId} = ${user.id} and ${lectureProgress.completed})::int`,
    })
    .from(enrollments)
    .innerJoin(courses, eq(courses.id, enrollments.courseId))
    .where(eq(enrollments.userId, user.id));

  const badges = await db
    .select({ code: userBadges.code, earnedAt: userBadges.earnedAt })
    .from(userBadges)
    .where(eq(userBadges.userId, user.id));

  const xpHistory = await db.execute(sql`
    select kind, sum(amount)::int as total
    from xp_events where user_id = ${user.id}
    group by kind order by total desc
  `);

  return ok({
    level: levelFor(user.xp || 0),
    xp: user.xp,
    streak: { current: user.streakCurrent, longest: user.streakLongest, lastStudyDate: user.lastStudyDate },
    weekly: (weekly.rows || []).map((r) => ({
      day: r.day,
      lectures: Number(r.lectures),
      quizzes: Number(r.quizzes),
      xp: Number(r.xp),
      minutes: Number(r.minutes),
    })),
    scores: scores.reverse(),
    courseProgress: courseProgress.map((c) => {
      const total = Number(c.lectureCount || 0);
      const done = Number(c.completedCount || 0);
      return { ...c, progressPercent: total ? Math.round((done / total) * 100) : 0 };
    }),
    badges,
    xpBreakdown: (xpHistory.rows || []).map((r) => ({ kind: r.kind, total: Number(r.total) })),
  });
});
