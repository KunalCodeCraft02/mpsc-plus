import { and, eq, desc, sql, gte } from "drizzle-orm";
import { db } from "@/db";
import {
  courses,
  lectures,
  quizzes,
  questions,
  enrollments,
  lectureProgress,
  quizAttempts,
  notifications,
  userBadges,
} from "@/db/schema";
import { handler, ok } from "@/server/http";
import { requireAuth } from "@/server/auth";
import { userRank } from "@/server/gamification";
import { levelFor } from "@/lib/config";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const user = await requireAuth(request);

  const myEnrollments = await db
    .select({
      courseId: enrollments.courseId,
      progressPercent: enrollments.progressPercent,
      title: courses.title,
      titleMr: courses.titleMr,
      thumbnailUrl: courses.thumbnailUrl,
      instructor: courses.instructor,
      isFree: courses.isFree,
      price: courses.price,
      currency: courses.currency,
      category: courses.category,
    })
    .from(enrollments)
    .innerJoin(courses, eq(courses.id, enrollments.courseId))
    .where(eq(enrollments.userId, user.id))
    .orderBy(desc(enrollments.createdAt));

  const recentProgress = await db
    .select({
      lectureId: lectureProgress.lectureId,
      percent: lectureProgress.percent,
      completed: lectureProgress.completed,
      updatedAt: lectureProgress.updatedAt,
      title: lectures.title,
      titleMr: lectures.titleMr,
      youtubeId: lectures.youtubeId,
      durationMin: lectures.durationMin,
      courseId: lectures.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
    })
    .from(lectureProgress)
    .innerJoin(lectures, eq(lectures.id, lectureProgress.lectureId))
    .innerJoin(courses, eq(courses.id, lectures.courseId))
    .where(eq(lectureProgress.userId, user.id))
    .orderBy(desc(lectureProgress.updatedAt))
    .limit(6);

  const upcomingTests = await db
    .select({
      id: quizzes.id,
      title: quizzes.title,
      titleMr: quizzes.titleMr,
      difficulty: quizzes.difficulty,
      timeLimitMin: quizzes.timeLimitMin,
      isFree: quizzes.isFree,
      courseId: quizzes.courseId,
      questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
    })
    .from(quizzes)
    .where(eq(quizzes.published, true))
    .orderBy(desc(quizzes.createdAt))
    .limit(4);

  const recommended = await db
    .select({
      id: courses.id,
      title: courses.title,
      titleMr: courses.titleMr,
      thumbnailUrl: courses.thumbnailUrl,
      instructor: courses.instructor,
      isFree: courses.isFree,
      price: courses.price,
      currency: courses.currency,
      category: courses.category,
      lectureCount: sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id} and ${lectures.published})::int`,
    })
    .from(courses)
    .where(eq(courses.published, true))
    .orderBy(desc(courses.createdAt))
    .limit(8);

  const enrolledIds = new Set(myEnrollments.map((e) => e.courseId));

  const since = new Date();
  since.setDate(since.getDate() - 6);
  const weekly = await db.execute(sql`
    with days as (
      select generate_series(current_date - interval '6 days', current_date, interval '1 day')::date as d
    )
    select days.d as day,
      (select count(*) from lecture_progress lp
        where lp.user_id = ${user.id} and lp.completed and lp.completed_at::date = days.d)::int as lectures,
      (select count(*) from quiz_attempts qa
        where qa.user_id = ${user.id} and qa.created_at::date = days.d)::int as quizzes,
      (select coalesce(sum(xe.amount),0) from xp_events xe
        where xe.user_id = ${user.id} and xe.created_at::date = days.d)::int as xp
    from days order by days.d
  `);

  const [badgeRows, attemptStats, rank, notif] = await Promise.all([
    db.select({ code: userBadges.code }).from(userBadges).where(eq(userBadges.userId, user.id)),
    db
      .select({
        attempts: sql`count(*)::int`,
        avg: sql`coalesce(round(avg(${quizAttempts.percent})),0)::int`,
      })
      .from(quizAttempts)
      .where(and(eq(quizAttempts.userId, user.id), gte(quizAttempts.createdAt, new Date(0)))),
    userRank(user.id),
    db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(3),
  ]);

  const level = levelFor(user.xp || 0);

  return ok({
    profile: {
      id: user.id,
      name: user.name,
      language: user.language,
      xp: user.xp,
      streakCurrent: user.streakCurrent,
      streakLongest: user.streakLongest,
      rank,
      level,
      badges: badgeRows.map((b) => b.code),
    },
    continueLearning: recentProgress.filter((r) => !r.completed).slice(0, 3),
    recentLectures: recentProgress.slice(0, 5),
    myCourses: myEnrollments,
    upcomingTests,
    recommended: recommended.filter((c) => !enrolledIds.has(c.id)).slice(0, 6),
    weekly: (weekly.rows || []).map((r) => ({
      day: r.day,
      lectures: Number(r.lectures),
      quizzes: Number(r.quizzes),
      xp: Number(r.xp),
    })),
    stats: {
      quizzesAttempted: Number(attemptStats[0]?.attempts || 0),
      avgScore: Number(attemptStats[0]?.avg || 0),
      coursesEnrolled: myEnrollments.length,
    },
    notifications: notif,
  });
});
