import { eq, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { courses, lectures, enrollments, lectureProgress, quizAttempts, quizzes } from "@/db/schema";
import { handler, ok } from "@/server/http";
import { requireAuth } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const user = await requireAuth(request);

  const rows = await db
    .select({
      courseId: enrollments.courseId,
      progressPercent: enrollments.progressPercent,
      enrolledAt: enrollments.createdAt,
      title: courses.title,
      titleMr: courses.titleMr,
      thumbnailUrl: courses.thumbnailUrl,
      instructor: courses.instructor,
      category: courses.category,
      isFree: courses.isFree,
      price: courses.price,
      currency: courses.currency,
      lectureCount: sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id} and ${lectures.published})::int`,
      completedCount: sql`(select count(*) from ${lectureProgress} where ${lectureProgress.courseId} = ${courses.id} and ${lectureProgress.userId} = ${user.id} and ${lectureProgress.completed})::int`,
    })
    .from(enrollments)
    .innerJoin(courses, eq(courses.id, enrollments.courseId))
    .where(eq(enrollments.userId, user.id))
    .orderBy(desc(enrollments.createdAt));

  const items = rows.map((r) => {
    const total = Number(r.lectureCount || 0);
    const done = Number(r.completedCount || 0);
    return { ...r, progressPercent: total ? Math.round((done / total) * 100) : 0 };
  });

  const activity = await db
    .select({
      kind: sql`'lecture'`,
      title: lectures.title,
      titleMr: lectures.titleMr,
      at: lectureProgress.updatedAt,
      courseTitle: courses.title,
      refId: lectures.id,
      completed: lectureProgress.completed,
    })
    .from(lectureProgress)
    .innerJoin(lectures, eq(lectures.id, lectureProgress.lectureId))
    .innerJoin(courses, eq(courses.id, lectures.courseId))
    .where(eq(lectureProgress.userId, user.id))
    .orderBy(desc(lectureProgress.updatedAt))
    .limit(8);

  const testActivity = await db
    .select({
      kind: sql`'quiz'`,
      title: quizzes.title,
      titleMr: quizzes.titleMr,
      at: quizAttempts.createdAt,
      percent: quizAttempts.percent,
      passed: quizAttempts.passed,
      refId: quizAttempts.id,
    })
    .from(quizAttempts)
    .innerJoin(quizzes, eq(quizzes.id, quizAttempts.quizId))
    .where(eq(quizAttempts.userId, user.id))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(8);

  return ok({
    inProgress: items.filter((i) => i.progressPercent < 100),
    completed: items.filter((i) => i.progressPercent >= 100),
    activity: [...activity, ...testActivity]
      .sort((a, b) => new Date(b.at) - new Date(a.at))
      .slice(0, 10),
  });
});
