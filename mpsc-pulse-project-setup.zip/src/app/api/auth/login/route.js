import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { handler, body, ok, fail } from "@/server/http";
import { verifyPassword, signToken, publicUser } from "@/server/auth";
import { loginSchema } from "@/server/validation";
import { ensureSeeded } from "@/server/seed";

export const POST = handler(async (request) => {
  const raw = await body(request);
  const data = loginSchema.parse(raw);

  try {
    await ensureSeeded();
  } catch {
    /* seeding is best-effort */
  }

  const identifier = data.identifier.trim().toLowerCase();
  const rows = await db
    .select()
    .from(users)
    .where(or(eq(users.email, identifier), eq(users.mobile, data.identifier.trim())))
    .limit(1);

  const user = rows[0];
  // Generic message — never reveal whether the account exists.
  if (!user) return fail(401, "Invalid credentials. Please check and try again.");

  const valid = await verifyPassword(data.password, user.passwordHash);
  if (!valid) return fail(401, "Invalid credentials. Please check and try again.");

  if (user.status !== "ACTIVE") {
    return fail(403, "This account has been deactivated. Please contact support.");
  }

  const token = signToken({ sub: String(user.id), role: user.role });
  return ok({ token, user: publicUser(user) });
});
