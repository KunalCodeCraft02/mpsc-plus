import { eq, and, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, userBadges, lectureProgress, quizAttempts, enrollments } from "@/db/schema";
import { handler, body, ok } from "@/server/http";
import { requireAuth, publicUser } from "@/server/auth";
import { userRank } from "@/server/gamification";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const user = await requireAuth(request);

  const [badges, lectureStats, attemptStats, enrolled, rank] = await Promise.all([
    db.select({ code: userBadges.code, earnedAt: userBadges.earnedAt }).from(userBadges).where(eq(userBadges.userId, user.id)),
    db
      .select({
        completed: sql`count(*) filter (where ${lectureProgress.completed})::int`,
        started: sql`count(*)::int`,
      })
      .from(lectureProgress)
      .where(eq(lectureProgress.userId, user.id)),
    db
      .select({
        attempts: sql`count(*)::int`,
        avg: sql`coalesce(round(avg(${quizAttempts.percent})), 0)::int`,
      })
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, user.id)),
    db
      .select({
        total: sql`count(*)::int`,
        completed: sql`count(*) filter (where ${enrollments.progressPercent} >= 100)::int`,
      })
      .from(enrollments)
      .where(eq(enrollments.userId, user.id)),
    user.role === "STUDENT" ? userRank(user.id) : Promise.resolve(null),
  ]);

  return ok({
    user: {
      ...publicUser(user),
      rank,
      badges: badges.map((b) => b.code),
      stats: {
        lecturesCompleted: Number(lectureStats[0]?.completed || 0),
        lecturesStarted: Number(lectureStats[0]?.started || 0),
        quizzesAttempted: Number(attemptStats[0]?.attempts || 0),
        avgScore: Number(attemptStats[0]?.avg || 0),
        coursesEnrolled: Number(enrolled[0]?.total || 0),
        coursesCompleted: Number(enrolled[0]?.completed || 0),
      },
    },
  });
});

export const PATCH = handler(async (request) => {
  const user = await requireAuth(request);
  const raw = await body(request);
  const patch = {};
  if (typeof raw.name === "string" && raw.name.trim().length >= 3) patch.name = raw.name.trim();
  if (raw.language === "en" || raw.language === "mr") patch.language = raw.language;
  if (typeof raw.avatarUrl === "string") patch.avatarUrl = raw.avatarUrl.slice(0, 500);

  if (!Object.keys(patch).length) return ok({ user: publicUser(user) });

  const [updated] = await db
    .update(users)
    .set(patch)
    .where(and(eq(users.id, user.id)))
    .returning();

  return ok({ user: publicUser(updated) });
});
