import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { handler, body, created, fail } from "@/server/http";
import { hashPassword, signToken, publicUser } from "@/server/auth";
import { registerSchema } from "@/server/validation";
import { POLICY } from "@/lib/config";

export const POST = handler(async (request) => {
  const raw = await body(request);
  const data = registerSchema.parse(raw);

  const existing = await db
    .select({ id: users.id, email: users.email, mobile: users.mobile })
    .from(users)
    .where(or(eq(users.email, data.email), eq(users.mobile, data.mobile)))
    .limit(1);

  if (existing.length) {
    const clash = existing[0].email === data.email ? "email" : "mobile";
    return fail(409, `An account already exists with this ${clash}.`, { field: clash });
  }

  const passwordHash = await hashPassword(data.password);

  const [user] = await db
    .insert(users)
    .values({
      name: data.name,
      email: data.email,
      mobile: data.mobile,
      passwordHash,
      role: "STUDENT",
      language: data.language,
      termsVersion: data.termsVersion || POLICY.termsVersion,
      privacyVersion: data.privacyVersion || POLICY.privacyVersion,
      acceptedAt: new Date(),
      platform: data.platform || "web",
    })
    .returning();

  const token = signToken({ sub: String(user.id), role: user.role });
  return created({ token, user: publicUser(user) });
});
