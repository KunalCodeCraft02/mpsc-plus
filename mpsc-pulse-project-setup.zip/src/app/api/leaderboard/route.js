import { eq, and, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, enrollments, xpEvents, courses } from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { currentUser } from "@/server/auth";
import { leaderboard, userRank } from "@/server/gamification";
import { levelFor } from "@/lib/config";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const q = query(request);
  const period = ["global", "weekly", "monthly"].includes(q.period) ? q.period : "global";
  const courseId = q.courseId ? num(q.courseId) : null;
  const limit = Math.min(100, Math.max(5, num(q.limit, 50)));

  let rows;
  if (courseId) {
    rows = await db
      .select({
        id: users.id,
        name: users.name,
        avatarUrl: users.avatarUrl,
        xp: users.xp,
        streakCurrent: users.streakCurrent,
        periodXp: users.xp,
        progressPercent: enrollments.progressPercent,
      })
      .from(enrollments)
      .innerJoin(users, eq(users.id, enrollments.userId))
      .where(and(eq(enrollments.courseId, courseId), eq(users.role, "STUDENT")))
      .orderBy(desc(enrollments.progressPercent), desc(users.xp))
      .limit(limit);
    rows = rows.map((r, i) => ({ ...r, rank: i + 1 }));
  } else {
    rows = await leaderboard({ period, limit });
  }

  const withLevel = rows.map((r) => {
    const lvl = levelFor(r.xp || 0);
    return { ...r, level: lvl.key, levelNumber: lvl.number };
  });

  const me = await currentUser(request);
  let mine = null;
  if (me) {
    const inList = withLevel.find((r) => r.id === me.id);
    const rank = inList?.rank ?? (await userRank(me.id));
    const above = withLevel.filter((r) => r.rank < rank).slice(-1)[0];
    const lvl = levelFor(me.xp || 0);
    mine = {
      id: me.id,
      name: me.name,
      avatarUrl: me.avatarUrl,
      xp: me.xp,
      streakCurrent: me.streakCurrent,
      rank,
      level: lvl.key,
      levelNumber: lvl.number,
      xpToNextRank: above ? Math.max(0, (above.periodXp ?? above.xp) - me.xp + 1) : 0,
    };
  }

  const courseOptions = await db
    .select({ id: courses.id, title: courses.title, titleMr: courses.titleMr })
    .from(courses)
    .where(eq(courses.published, true));

  const [{ n = 0 } = {}] = await db
    .select({ n: sql`count(*)::int` })
    .from(xpEvents);

  return ok({
    period,
    courseId,
    items: withLevel,
    me: mine,
    courses: courseOptions,
    xpEventCount: Number(n),
  });
});
