import { and, eq, ilike, or, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { courses, subjects, lectures, quizzes, pdfs, searchQueries } from "@/db/schema";
import { handler, ok, query } from "@/server/http";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  const q = (query(request).q || "").trim();
  if (q.length < 2) {
    const pop = await db
      .select({ q: searchQueries.q })
      .from(searchQueries)
      .orderBy(desc(searchQueries.hits))
      .limit(8);
    return ok({ suggestions: pop.map((p) => ({ label: p.q, kind: "popular" })) });
  }

  const like = `%${q}%`;
  const [c, s, l, z, p] = await Promise.all([
    db
      .select({ label: courses.title, labelMr: courses.titleMr, id: courses.id })
      .from(courses)
      .where(and(eq(courses.published, true), or(ilike(courses.title, like), ilike(courses.titleMr, like))))
      .limit(4),
    db
      .select({ label: subjects.name, labelMr: subjects.nameMr, id: subjects.id, courseId: subjects.courseId })
      .from(subjects)
      .where(or(ilike(subjects.name, like), ilike(subjects.nameMr, like)))
      .limit(4),
    db
      .select({ label: lectures.title, labelMr: lectures.titleMr, id: lectures.id })
      .from(lectures)
      .where(and(eq(lectures.published, true), or(ilike(lectures.title, like), ilike(lectures.titleMr, like))))
      .limit(4),
    db
      .select({ label: quizzes.title, labelMr: quizzes.titleMr, id: quizzes.id })
      .from(quizzes)
      .where(and(eq(quizzes.published, true), or(ilike(quizzes.title, like), ilike(quizzes.titleMr, like))))
      .limit(4),
    db
      .select({ label: pdfs.title, labelMr: pdfs.titleMr, id: pdfs.id })
      .from(pdfs)
      .where(and(eq(pdfs.published, true), or(ilike(pdfs.title, like), ilike(pdfs.titleMr, like))))
      .limit(3),
  ]);

  const suggestions = [
    ...c.map((r) => ({ ...r, kind: "course" })),
    ...s.map((r) => ({ ...r, kind: "subject" })),
    ...l.map((r) => ({ ...r, kind: "lecture" })),
    ...z.map((r) => ({ ...r, kind: "quiz" })),
    ...p.map((r) => ({ ...r, kind: "pdf" })),
  ];

  const [{ n = 0 } = {}] = await db.select({ n: sql`count(*)::int` }).from(searchQueries);

  return ok({ suggestions, indexed: Number(n) });
});
