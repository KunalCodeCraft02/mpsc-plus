import { and, eq, ilike, or, sql, desc } from "drizzle-orm";
import { db } from "@/db";
import {
  courses,
  subjects,
  chapters,
  lectures,
  pdfs,
  quizzes,
  questions,
  searchQueries,
} from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { ensureSeeded } from "@/server/seed";

export const dynamic = "force-dynamic";

const TYPES = ["courses", "lectures", "pdfs", "quizzes", "subjects", "chapters"];

async function popular(limit = 8) {
  return db
    .select({ q: searchQueries.q, hits: searchQueries.hits })
    .from(searchQueries)
    .orderBy(desc(searchQueries.hits))
    .limit(limit);
}

export const GET = handler(async (request) => {
  try {
    await ensureSeeded();
  } catch {
    /* ignore */
  }

  const p = query(request);
  const q = (p.q || "").trim();
  const type = TYPES.includes(p.type) ? p.type : "all";
  const page = Math.max(1, num(p.page, 1));
  const perPage = Math.min(50, Math.max(1, num(p.perPage, 20)));
  const access = p.access || "all";
  const language = p.language || "all";
  const category = p.category || "all";

  if (!q) {
    return ok({
      query: "",
      items: [],
      total: 0,
      popular: (await popular()).map((r) => r.q),
      suggestions: [],
      counts: {},
    });
  }

  const like = `%${q}%`;

  // Log the query for the "popular searches" panel (fire and forget semantics).
  db.insert(searchQueries)
    .values({ q: q.toLowerCase().slice(0, 160), hits: 1 })
    .onConflictDoUpdate({
      target: searchQueries.q,
      set: { hits: sql`${searchQueries.hits} + 1`, updatedAt: new Date() },
    })
    .catch(() => {});

  const accessCond = (col) =>
    access === "free" ? eq(col, true) : access === "paid" ? eq(col, false) : undefined;

  /* ---- Courses ---- */
  const courseConds = [
    eq(courses.published, true),
    or(
      ilike(courses.title, like),
      ilike(courses.titleMr, like),
      ilike(courses.description, like),
      ilike(courses.instructor, like),
      ilike(courses.category, like),
    ),
  ];
  if (accessCond(courses.isFree)) courseConds.push(accessCond(courses.isFree));
  if (category !== "all") courseConds.push(eq(courses.category, category));
  if (language !== "all") courseConds.push(eq(courses.language, language));

  const courseRows = await db
    .select({
      id: courses.id,
      title: courses.title,
      titleMr: courses.titleMr,
      subtitle: courses.instructor,
      category: courses.category,
      isFree: courses.isFree,
      price: courses.price,
      currency: courses.currency,
      thumbnailUrl: courses.thumbnailUrl,
      courseId: courses.id,
      courseTitle: courses.title,
    })
    .from(courses)
    .where(and(...courseConds))
    .limit(50);

  /* ---- Lectures ---- */
  const lectureConds = [
    eq(lectures.published, true),
    or(ilike(lectures.title, like), ilike(lectures.titleMr, like), ilike(lectures.description, like)),
  ];
  if (accessCond(lectures.isFree)) lectureConds.push(accessCond(lectures.isFree));

  const lectureRows = await db
    .select({
      id: lectures.id,
      title: lectures.title,
      titleMr: lectures.titleMr,
      subtitle: lectures.description,
      isFree: lectures.isFree,
      youtubeId: lectures.youtubeId,
      durationMin: lectures.durationMin,
      courseId: lectures.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
    })
    .from(lectures)
    .innerJoin(courses, eq(courses.id, lectures.courseId))
    .where(and(...lectureConds, eq(courses.published, true)))
    .limit(50);

  /* ---- PDFs ---- */
  const pdfConds = [
    eq(pdfs.published, true),
    or(ilike(pdfs.title, like), ilike(pdfs.titleMr, like), ilike(pdfs.description, like)),
  ];
  if (accessCond(pdfs.isFree)) pdfConds.push(accessCond(pdfs.isFree));

  const pdfRows = await db
    .select({
      id: pdfs.id,
      title: pdfs.title,
      titleMr: pdfs.titleMr,
      subtitle: pdfs.description,
      isFree: pdfs.isFree,
      pageCount: pdfs.pageCount,
      fileSizeKb: pdfs.fileSizeKb,
      courseId: pdfs.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
    })
    .from(pdfs)
    .innerJoin(courses, eq(courses.id, pdfs.courseId))
    .where(and(...pdfConds, eq(courses.published, true)))
    .limit(50);

  /* ---- Quizzes ---- */
  const quizConds = [
    eq(quizzes.published, true),
    or(ilike(quizzes.title, like), ilike(quizzes.titleMr, like), ilike(quizzes.description, like)),
  ];
  if (accessCond(quizzes.isFree)) quizConds.push(accessCond(quizzes.isFree));

  const quizRows = await db
    .select({
      id: quizzes.id,
      title: quizzes.title,
      titleMr: quizzes.titleMr,
      subtitle: quizzes.description,
      isFree: quizzes.isFree,
      difficulty: quizzes.difficulty,
      timeLimitMin: quizzes.timeLimitMin,
      courseId: quizzes.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
      questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
    })
    .from(quizzes)
    .innerJoin(courses, eq(courses.id, quizzes.courseId))
    .where(and(...quizConds, eq(courses.published, true)))
    .limit(50);

  /* ---- Subjects & chapters ---- */
  const subjectRows = await db
    .select({
      id: subjects.id,
      title: subjects.name,
      titleMr: subjects.nameMr,
      subtitle: subjects.description,
      courseId: subjects.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
    })
    .from(subjects)
    .innerJoin(courses, eq(courses.id, subjects.courseId))
    .where(
      and(
        eq(courses.published, true),
        or(ilike(subjects.name, like), ilike(subjects.nameMr, like)),
      ),
    )
    .limit(30);

  const chapterRows = await db
    .select({
      id: chapters.id,
      title: chapters.title,
      titleMr: chapters.titleMr,
      subtitle: chapters.description,
      courseId: chapters.courseId,
      courseTitle: courses.title,
      courseTitleMr: courses.titleMr,
    })
    .from(chapters)
    .innerJoin(courses, eq(courses.id, chapters.courseId))
    .where(
      and(
        eq(courses.published, true),
        or(ilike(chapters.title, like), ilike(chapters.titleMr, like)),
      ),
    )
    .limit(30);

  const tag = (rows, kind) => rows.map((r) => ({ ...r, kind }));

  const buckets = {
    courses: tag(courseRows, "course"),
    lectures: tag(lectureRows, "lecture"),
    pdfs: tag(pdfRows, "pdf"),
    quizzes: tag(quizRows, "quiz"),
    subjects: tag(subjectRows, "subject"),
    chapters: tag(chapterRows, "chapter"),
  };

  const counts = Object.fromEntries(Object.entries(buckets).map(([k, v]) => [k, v.length]));
  counts.all = Object.values(counts).reduce((a, b) => a + b, 0);

  const lower = q.toLowerCase();
  const relevance = (item) => {
    const t = String(item.title || "").toLowerCase();
    if (t === lower) return 0;
    if (t.startsWith(lower)) return 1;
    if (t.includes(lower)) return 2;
    return 3;
  };

  const merged =
    type === "all"
      ? [
          ...buckets.courses,
          ...buckets.lectures,
          ...buckets.quizzes,
          ...buckets.pdfs,
          ...buckets.subjects,
          ...buckets.chapters,
        ]
      : buckets[type] || [];

  merged.sort((a, b) => relevance(a) - relevance(b));

  const total = merged.length;
  const items = merged.slice((page - 1) * perPage, page * perPage);

  return ok({
    query: q,
    type,
    items,
    counts,
    total,
    page,
    perPage,
    pages: Math.max(1, Math.ceil(total / perPage)),
    popular: (await popular(6)).map((r) => r.q),
  });
});
