import { sql, eq, desc, and, gte } from "drizzle-orm";
import { db } from "@/db";
import {
  users,
  courses,
  lectures,
  pdfs,
  quizzes,
  quizAttempts,
  enrollments,
  lectureProgress,
  auditLogs,
} from "@/db/schema";
import { handler, ok } from "@/server/http";
import { requireAdmin } from "@/server/auth";
import { ensureSeeded } from "@/server/seed";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  await requireAdmin(request);
  try {
    await ensureSeeded();
  } catch {
    /* ignore */
  }

  const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);

  const [
    studentCount,
    activeCount,
    courseCount,
    lectureCount,
    pdfCount,
    quizCount,
    attemptCount,
    enrollCount,
  ] = await Promise.all([
    db.select({ n: sql`count(*)::int` }).from(users).where(eq(users.role, "STUDENT")),
    db
      .select({ n: sql`count(distinct ${lectureProgress.userId})::int` })
      .from(lectureProgress)
      .where(gte(lectureProgress.updatedAt, sevenDaysAgo)),
    db.select({ n: sql`count(*)::int`, published: sql`count(*) filter (where published)::int` }).from(courses),
    db.select({ n: sql`count(*)::int`, published: sql`count(*) filter (where published)::int` }).from(lectures),
    db.select({ n: sql`count(*)::int`, published: sql`count(*) filter (where published)::int` }).from(pdfs),
    db.select({ n: sql`count(*)::int`, published: sql`count(*) filter (where published)::int` }).from(quizzes),
    db.select({ n: sql`count(*)::int` }).from(quizAttempts),
    db.select({ n: sql`count(*)::int` }).from(enrollments),
  ]);

  const growth = await db.execute(sql`
    with days as (
      select generate_series(current_date - interval '13 days', current_date, interval '1 day')::date as d
    )
    select to_char(days.d, 'DD Mon') as label,
      (select count(*) from users u where u.created_at::date <= days.d and u.role = 'STUDENT')::int as total,
      (select count(*) from users u where u.created_at::date = days.d and u.role = 'STUDENT')::int as added
    from days order by days.d
  `);

  const topCourses = await db
    .select({
      id: courses.id,
      title: courses.title,
      titleMr: courses.titleMr,
      isFree: courses.isFree,
      price: courses.price,
      published: courses.published,
      students: sql`(select count(*) from ${enrollments} where ${enrollments.courseId} = ${courses.id})::int`,
      lectures: sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id})::int`,
    })
    .from(courses)
    .orderBy(desc(sql`(select count(*) from ${enrollments} where ${enrollments.courseId} = ${courses.id})`))
    .limit(5);

  const recentStudents = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      createdAt: users.createdAt,
      xp: users.xp,
      status: users.status,
    })
    .from(users)
    .where(eq(users.role, "STUDENT"))
    .orderBy(desc(users.createdAt))
    .limit(6);

  const recentLectures = await db
    .select({
      id: lectures.id,
      title: lectures.title,
      createdAt: lectures.createdAt,
      published: lectures.published,
      courseTitle: courses.title,
      durationMin: lectures.durationMin,
    })
    .from(lectures)
    .leftJoin(courses, eq(courses.id, lectures.courseId))
    .orderBy(desc(lectures.createdAt))
    .limit(6);

  const recentAttempts = await db
    .select({
      id: quizAttempts.id,
      percent: quizAttempts.percent,
      passed: quizAttempts.passed,
      createdAt: quizAttempts.createdAt,
      studentName: users.name,
      quizTitle: quizzes.title,
    })
    .from(quizAttempts)
    .innerJoin(users, eq(users.id, quizAttempts.userId))
    .innerJoin(quizzes, eq(quizzes.id, quizAttempts.quizId))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(6);

  const topStudents = await db
    .select({ id: users.id, name: users.name, xp: users.xp, streakCurrent: users.streakCurrent })
    .from(users)
    .where(eq(users.role, "STUDENT"))
    .orderBy(desc(users.xp))
    .limit(5);

  const audit = await db
    .select()
    .from(auditLogs)
    .orderBy(desc(auditLogs.createdAt))
    .limit(6);

  const engagement = await db.execute(sql`
    select c.title as label, count(lp.id)::int as value
    from courses c
    left join lecture_progress lp on lp.course_id = c.id
    group by c.title order by value desc limit 6
  `);

  const quizPerf = await db.execute(sql`
    select q.title as label,
           coalesce(round(avg(a.percent)),0)::int as value,
           count(a.id)::int as attempts
    from quizzes q left join quiz_attempts a on a.quiz_id = q.id
    group by q.title order by attempts desc limit 6
  `);

  return ok({
    cards: {
      students: Number(studentCount[0]?.n || 0),
      activeStudents: Number(activeCount[0]?.n || 0),
      courses: Number(courseCount[0]?.n || 0),
      coursesPublished: Number(courseCount[0]?.published || 0),
      lectures: Number(lectureCount[0]?.n || 0),
      lecturesPublished: Number(lectureCount[0]?.published || 0),
      pdfs: Number(pdfCount[0]?.n || 0),
      pdfsPublished: Number(pdfCount[0]?.published || 0),
      quizzes: Number(quizCount[0]?.n || 0),
      quizzesPublished: Number(quizCount[0]?.published || 0),
      attempts: Number(attemptCount[0]?.n || 0),
      enrollments: Number(enrollCount[0]?.n || 0),
    },
    growth: (growth.rows || []).map((r) => ({
      label: r.label,
      value: Number(r.total),
      added: Number(r.added),
    })),
    engagement: (engagement.rows || []).map((r) => ({ label: r.label, value: Number(r.value) })),
    quizPerformance: (quizPerf.rows || []).map((r) => ({
      label: r.label,
      value: Number(r.value),
      attempts: Number(r.attempts),
    })),
    topCourses,
    recentStudents,
    recentLectures,
    recentAttempts,
    topStudents,
    audit,
  });
});
