import { sql, eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { quizzes, questions, quizAttempts, courses } from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { requireAdmin } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  await requireAdmin(request);
  const q = query(request);
  const quizId = q.quizId ? num(q.quizId) : null;

  const lectureCompletion = await db.execute(sql`
    select c.title as label,
           count(distinct l.id)::int as total,
           count(lp.id) filter (where lp.completed)::int as completed
    from courses c
    left join lectures l on l.course_id = c.id and l.published
    left join lecture_progress lp on lp.lecture_id = l.id
    group by c.title order by total desc limit 8
  `);

  const enrollmentTrend = await db.execute(sql`
    with days as (
      select generate_series(current_date - interval '13 days', current_date, interval '1 day')::date as d
    )
    select to_char(days.d, 'DD Mon') as label,
      (select count(*) from enrollments e where e.created_at::date = days.d)::int as value
    from days order by days.d
  `);

  const quizStats = await db
    .select({
      id: quizzes.id,
      title: quizzes.title,
      difficulty: quizzes.difficulty,
      passingPercent: quizzes.passingPercent,
      questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
      attempts: sql`(select count(*) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      avgScore: sql`(select coalesce(round(avg(percent)),0) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      highest: sql`(select coalesce(max(percent),0) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      lowest: sql`(select coalesce(min(percent),0) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      passRate: sql`(select coalesce(round(100.0 * count(*) filter (where passed) / greatest(count(*),1)),0) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      avgTimeSec: sql`(select coalesce(round(avg(time_taken_sec)),0) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})::int`,
      courseTitle: courses.title,
    })
    .from(quizzes)
    .leftJoin(courses, eq(courses.id, quizzes.courseId))
    .orderBy(desc(sql`(select count(*) from ${quizAttempts} where ${quizAttempts.quizId} = ${quizzes.id})`))
    .limit(20);

  /* Hardest questions: share of incorrect answers across stored attempt reviews. */
  let hardest = [];
  if (quizId || quizStats.length) {
    const targetId = quizId || quizStats[0]?.id;
    if (targetId) {
      const res = await db.execute(sql`
        select r->>'text' as text,
               count(*)::int as answered,
               count(*) filter (where r->>'state' = 'incorrect')::int as wrong
        from quiz_attempts a,
             jsonb_array_elements(coalesce(a.answers->'review','[]'::jsonb)) as r
        where a.quiz_id = ${targetId}
        group by r->>'text'
        order by wrong desc, answered desc
        limit 8
      `);
      hardest = (res.rows || []).map((r) => ({
        text: r.text,
        answered: Number(r.answered),
        wrong: Number(r.wrong),
        errorRate: Number(r.answered) ? Math.round((Number(r.wrong) / Number(r.answered)) * 100) : 0,
      }));
    }
  }

  const xpDistribution = await db.execute(sql`
    select kind as label, sum(amount)::int as value
    from xp_events group by kind order by value desc
  `);

  return ok({
    lectureCompletion: (lectureCompletion.rows || []).map((r) => ({
      label: r.label,
      total: Number(r.total),
      completed: Number(r.completed),
      value: Number(r.total) ? Math.round((Number(r.completed) / Number(r.total)) * 100) : 0,
    })),
    enrollmentTrend: (enrollmentTrend.rows || []).map((r) => ({
      label: r.label,
      value: Number(r.value),
    })),
    quizStats,
    hardest,
    xpDistribution: (xpDistribution.rows || []).map((r) => ({ label: r.label, value: Number(r.value) })),
  });
});
