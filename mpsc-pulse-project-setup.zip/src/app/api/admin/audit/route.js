import { desc, ilike, or, and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { handler, ok, query, num } from "@/server/http";
import { requireAdmin } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request) => {
  await requireAdmin(request);
  const q = query(request);
  const page = Math.max(1, num(q.page, 1));
  const perPage = Math.min(100, Math.max(1, num(q.perPage, 20)));

  const conditions = [];
  if (q.q) {
    const like = `%${q.q}%`;
    conditions.push(
      or(ilike(auditLogs.detail, like), ilike(auditLogs.adminName, like), ilike(auditLogs.entity, like)),
    );
  }
  if (q.entity && q.entity !== "all") conditions.push(eq(auditLogs.entity, q.entity));
  if (q.action && q.action !== "all") conditions.push(eq(auditLogs.action, q.action));
  const where = conditions.length ? and(...conditions) : undefined;

  let listQ = db.select().from(auditLogs);
  if (where) listQ = listQ.where(where);
  const items = await listQ
    .orderBy(desc(auditLogs.createdAt))
    .limit(perPage)
    .offset((page - 1) * perPage);

  let countQ = db.select({ n: sql`count(*)::int` }).from(auditLogs);
  if (where) countQ = countQ.where(where);
  const [{ n = 0 } = {}] = await countQ;

  return ok({
    items,
    total: Number(n),
    page,
    perPage,
    pages: Math.max(1, Math.ceil(Number(n) / perPage)),
  });
});
