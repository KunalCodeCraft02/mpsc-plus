import { and, eq, asc } from "drizzle-orm";
import { db } from "@/db";
import {
  lectures,
  courses,
  chapters,
  subjects,
  pdfs,
  enrollments,
  lectureProgress,
} from "@/db/schema";
import { handler, ok, fail } from "@/server/http";
import { currentUser } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const lectureId = Number(id);
  if (!Number.isFinite(lectureId)) return fail(400, "Invalid lecture id");

  const [lecture] = await db.select().from(lectures).where(eq(lectures.id, lectureId)).limit(1);
  if (!lecture || !lecture.published) return fail(404, "Lecture not found");

  const [course] = await db.select().from(courses).where(eq(courses.id, lecture.courseId)).limit(1);
  const user = await currentUser(request);

  let enrollment = null;
  if (user) {
    const [e] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, lecture.courseId)))
      .limit(1);
    enrollment = e || null;
  }

  const hasAccess = course?.isFree || lecture.isFree || !!enrollment || user?.role === "ADMIN";
  if (!hasAccess) {
    return fail(403, "Enrol in this course to watch this lecture.", {
      locked: true,
      courseId: lecture.courseId,
    });
  }

  const siblings = await db
    .select({
      id: lectures.id,
      title: lectures.title,
      titleMr: lectures.titleMr,
      chapterId: lectures.chapterId,
      durationMin: lectures.durationMin,
      isFree: lectures.isFree,
      orderIndex: lectures.orderIndex,
      youtubeId: lectures.youtubeId,
    })
    .from(lectures)
    .where(and(eq(lectures.courseId, lecture.courseId), eq(lectures.published, true)))
    .orderBy(asc(lectures.chapterId), asc(lectures.orderIndex));

  const [chapter] = lecture.chapterId
    ? await db.select().from(chapters).where(eq(chapters.id, lecture.chapterId)).limit(1)
    : [null];
  const [subject] = lecture.subjectId
    ? await db.select().from(subjects).where(eq(subjects.id, lecture.subjectId)).limit(1)
    : [null];

  const chapterRows = await db
    .select()
    .from(chapters)
    .where(eq(chapters.courseId, lecture.courseId))
    .orderBy(asc(chapters.orderIndex));

  const attachedPdfs = lecture.chapterId
    ? await db
        .select()
        .from(pdfs)
        .where(and(eq(pdfs.chapterId, lecture.chapterId), eq(pdfs.published, true)))
    : [];

  let progress = null;
  let progressMap = {};
  if (user) {
    const rows = await db
      .select()
      .from(lectureProgress)
      .where(and(eq(lectureProgress.userId, user.id), eq(lectureProgress.courseId, lecture.courseId)));
    progressMap = Object.fromEntries(rows.map((r) => [r.lectureId, r]));
    progress = progressMap[lectureId] || null;
  }

  const idx = siblings.findIndex((s) => s.id === lectureId);
  const completedCount = Object.values(progressMap).filter((p) => p.completed).length;

  return ok({
    lecture,
    course: course ? { id: course.id, title: course.title, titleMr: course.titleMr, isFree: course.isFree } : null,
    chapter,
    subject,
    chapters: chapterRows.map((c) => ({
      ...c,
      lectures: siblings
        .filter((s) => s.chapterId === c.id)
        .map((s) => ({
          ...s,
          completed: !!progressMap[s.id]?.completed,
          progress: progressMap[s.id]?.percent || 0,
        })),
    })),
    pdfs: attachedPdfs,
    prev: idx > 0 ? siblings[idx - 1] : null,
    next: idx >= 0 && idx < siblings.length - 1 ? siblings[idx + 1] : null,
    progress,
    courseProgressPercent: siblings.length
      ? Math.round((completedCount / siblings.length) * 100)
      : 0,
  });
});
