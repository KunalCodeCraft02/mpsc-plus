import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { enrollments, courses } from "@/db/schema";
import { handler, body, ok, fail } from "@/server/http";
import { requireAuth } from "@/server/auth";

export const POST = handler(async (request) => {
  const user = await requireAuth(request);
  const { courseId } = await body(request);
  const id = Number(courseId);
  if (!Number.isFinite(id)) return fail(400, "Invalid course id");

  const [course] = await db.select().from(courses).where(eq(courses.id, id)).limit(1);
  if (!course || !course.published) return fail(404, "Course not found");

  // Paid courses require a completed order — payments are out of scope for now,
  // so we only auto-enrol free courses and never trust a client "paid" flag.
  if (!course.isFree) {
    return fail(402, "This is a paid course. Payment checkout is not enabled yet.", {
      price: course.price,
      currency: course.currency,
    });
  }

  const [existing] = await db
    .select()
    .from(enrollments)
    .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, id)))
    .limit(1);

  if (existing) return ok({ enrollment: existing, alreadyEnrolled: true });

  const [enrollment] = await db
    .insert(enrollments)
    .values({ userId: user.id, courseId: id })
    .returning();

  return ok({ enrollment, alreadyEnrolled: false });
});
