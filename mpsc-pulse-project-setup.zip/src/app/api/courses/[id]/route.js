import { and, eq, asc, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  courses,
  subjects,
  chapters,
  lectures,
  pdfs,
  quizzes,
  questions,
  enrollments,
  lectureProgress,
} from "@/db/schema";
import { handler, ok, fail } from "@/server/http";
import { currentUser } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const courseId = Number(id);
  if (!Number.isFinite(courseId)) return fail(400, "Invalid course id");

  const [course] = await db.select().from(courses).where(eq(courses.id, courseId)).limit(1);
  if (!course || !course.published) return fail(404, "Course not found");

  const user = await currentUser(request);

  const [subjectRows, chapterRows, lectureRows, pdfRows, quizRows, studentCount] =
    await Promise.all([
      db.select().from(subjects).where(eq(subjects.courseId, courseId)).orderBy(asc(subjects.orderIndex)),
      db.select().from(chapters).where(eq(chapters.courseId, courseId)).orderBy(asc(chapters.orderIndex)),
      db
        .select()
        .from(lectures)
        .where(and(eq(lectures.courseId, courseId), eq(lectures.published, true)))
        .orderBy(asc(lectures.orderIndex)),
      db
        .select()
        .from(pdfs)
        .where(and(eq(pdfs.courseId, courseId), eq(pdfs.published, true)))
        .orderBy(asc(pdfs.id)),
      db
        .select({
          id: quizzes.id,
          title: quizzes.title,
          titleMr: quizzes.titleMr,
          difficulty: quizzes.difficulty,
          timeLimitMin: quizzes.timeLimitMin,
          isFree: quizzes.isFree,
          passingPercent: quizzes.passingPercent,
          questionCount: sql`(select count(*) from ${questions} where ${questions.quizId} = ${quizzes.id})::int`,
        })
        .from(quizzes)
        .where(and(eq(quizzes.courseId, courseId), eq(quizzes.published, true))),
      db.select({ n: sql`count(*)::int` }).from(enrollments).where(eq(enrollments.courseId, courseId)),
    ]);

  let enrollment = null;
  let progressMap = {};
  if (user) {
    const [e] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, courseId)))
      .limit(1);
    enrollment = e || null;
    const prog = await db
      .select()
      .from(lectureProgress)
      .where(and(eq(lectureProgress.userId, user.id), eq(lectureProgress.courseId, courseId)));
    progressMap = Object.fromEntries(prog.map((p) => [p.lectureId, p]));
  }

  const hasAccess = course.isFree || !!enrollment || user?.role === "ADMIN";

  const curriculum = subjectRows.map((s) => ({
    ...s,
    chapters: chapterRows
      .filter((c) => c.subjectId === s.id)
      .map((c) => ({
        ...c,
        lectures: lectureRows
          .filter((l) => l.chapterId === c.id)
          .map((l) => ({
            ...l,
            locked: !hasAccess && !l.isFree,
            progress: progressMap[l.id]?.percent || 0,
            completed: !!progressMap[l.id]?.completed,
          })),
        pdfs: pdfRows
          .filter((p) => p.chapterId === c.id)
          .map((p) => ({ ...p, locked: !hasAccess && !p.isFree })),
      })),
  }));

  const completedCount = Object.values(progressMap).filter((p) => p.completed).length;
  const progressPercent = lectureRows.length
    ? Math.round((completedCount / lectureRows.length) * 100)
    : 0;

  return ok({
    course: {
      ...course,
      lectureCount: lectureRows.length,
      pdfCount: pdfRows.length,
      quizCount: quizRows.length,
      studentCount: Number(studentCount[0]?.n || 0),
      totalDurationMin: lectureRows.reduce((s, l) => s + (l.durationMin || 0), 0),
    },
    curriculum,
    quizzes: quizRows.map((q) => ({ ...q, locked: !hasAccess && !q.isFree })),
    pdfs: pdfRows.map((p) => ({ ...p, locked: !hasAccess && !p.isFree })),
    enrollment,
    hasAccess,
    progressPercent,
    nextLecture:
      lectureRows.find((l) => !progressMap[l.id]?.completed && (hasAccess || l.isFree)) ||
      lectureRows[0] ||
      null,
  });
});
