import { and, eq, ilike, or, sql, desc, asc } from "drizzle-orm";
import { db } from "@/db";
import { courses, lectures, pdfs, quizzes, enrollments } from "@/db/schema";
import { handler, ok, query, num, bool } from "@/server/http";
import { ensureSeeded } from "@/server/seed";

export const dynamic = "force-dynamic";

const lectureCount = sql`(select count(*) from ${lectures} where ${lectures.courseId} = ${courses.id} and ${lectures.published})::int`;
const pdfCount = sql`(select count(*) from ${pdfs} where ${pdfs.courseId} = ${courses.id} and ${pdfs.published})::int`;
const quizCount = sql`(select count(*) from ${quizzes} where ${quizzes.courseId} = ${courses.id} and ${quizzes.published})::int`;
const studentCount = sql`(select count(*) from ${enrollments} where ${enrollments.courseId} = ${courses.id})::int`;

export const GET = handler(async (request) => {
  try {
    await ensureSeeded();
  } catch {
    /* ignore */
  }

  const q = query(request);
  const page = Math.max(1, num(q.page, 1));
  const perPage = Math.min(48, Math.max(1, num(q.perPage, 12)));

  const conditions = [eq(courses.published, true)];
  if (q.q) {
    conditions.push(
      or(
        ilike(courses.title, `%${q.q}%`),
        ilike(courses.titleMr, `%${q.q}%`),
        ilike(courses.instructor, `%${q.q}%`),
        ilike(courses.category, `%${q.q}%`),
      ),
    );
  }
  if (q.category && q.category !== "all") conditions.push(eq(courses.category, q.category));
  if (q.access === "free") conditions.push(eq(courses.isFree, true));
  if (q.access === "paid") conditions.push(eq(courses.isFree, false));
  if (q.language && q.language !== "all") conditions.push(eq(courses.language, q.language));
  if (q.featured != null && bool(q.featured)) conditions.push(eq(courses.isFree, true));

  const where = and(...conditions);

  const orderBy =
    q.sort === "price_asc"
      ? asc(courses.price)
      : q.sort === "price_desc"
        ? desc(courses.price)
        : q.sort === "title"
          ? asc(courses.title)
          : desc(courses.createdAt);

  const [rows, totalRow, categories] = await Promise.all([
    db
      .select({
        id: courses.id,
        title: courses.title,
        titleMr: courses.titleMr,
        slug: courses.slug,
        description: courses.description,
        descriptionMr: courses.descriptionMr,
        thumbnailUrl: courses.thumbnailUrl,
        instructor: courses.instructor,
        category: courses.category,
        language: courses.language,
        isFree: courses.isFree,
        price: courses.price,
        currency: courses.currency,
        validityDays: courses.validityDays,
        createdAt: courses.createdAt,
        lectureCount,
        pdfCount,
        quizCount,
        studentCount,
      })
      .from(courses)
      .where(where)
      .orderBy(orderBy)
      .limit(perPage)
      .offset((page - 1) * perPage),
    db.select({ n: sql`count(*)::int` }).from(courses).where(where),
    db
      .select({ category: courses.category, n: sql`count(*)::int` })
      .from(courses)
      .where(eq(courses.published, true))
      .groupBy(courses.category),
  ]);

  const total = Number(totalRow[0]?.n || 0);

  return ok({
    items: rows,
    total,
    page,
    perPage,
    pages: Math.max(1, Math.ceil(total / perPage)),
    facets: {
      categories: categories.filter((c) => c.category).map((c) => ({ value: c.category, count: Number(c.n) })),
    },
  });
});
