import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { quizAttempts, quizzes, courses } from "@/db/schema";
import { handler, ok, fail } from "@/server/http";
import { requireAuth } from "@/server/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async (request, ctx) => {
  const { id } = await ctx.params;
  const user = await requireAuth(request);

  const [attempt] = await db
    .select()
    .from(quizAttempts)
    .where(and(eq(quizAttempts.id, Number(id)), eq(quizAttempts.userId, user.id)))
    .limit(1);

  if (!attempt) return fail(404, "Result not found");

  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, attempt.quizId)).limit(1);
  const [course] = quiz
    ? await db.select().from(courses).where(eq(courses.id, quiz.courseId)).limit(1)
    : [null];

  return ok({
    attempt: {
      ...attempt,
      review: attempt.answers?.review || [],
    },
    quiz: quiz
      ? {
          id: quiz.id,
          title: quiz.title,
          titleMr: quiz.titleMr,
          difficulty: quiz.difficulty,
          passingPercent: quiz.passingPercent,
          timeLimitMin: quiz.timeLimitMin,
        }
      : null,
    course: course ? { id: course.id, title: course.title, titleMr: course.titleMr } : null,
  });
});
