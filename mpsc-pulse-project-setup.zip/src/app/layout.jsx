import "./globals.css";
import AppProviders from "@/context/AppProviders";

export const metadata = {
  title: "MPSC Pulse — Pulse of MPSC",
  description:
    "Your complete MPSC preparation platform: recorded lectures, PDF notes, tests with analysis, XP and leaderboards — in Marathi and English.",
  applicationName: "MPSC Pulse",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "MPSC Pulse",
    statusBarStyle: "default",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#5b34e0",
  viewportFit: "cover",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-dvh antialiased">
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
