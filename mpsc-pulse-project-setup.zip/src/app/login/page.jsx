"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { LogIn, User, Info } from "lucide-react";
import { AuthShell } from "@/components/layout/AuthShell";
import { useI18n } from "@/context/I18nContext";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { useQuery } from "@/hooks/useQuery";
import { Button, Input, PasswordInput, Alert } from "@/components/ui";
import { loginSchema } from "@/server/validation";

export default function LoginPage() {
  const { t } = useI18n();
  const { login } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const params = useQuery();
  const [serverError, setServerError] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setValue,
  } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { identifier: "", password: "" },
  });

  const onSubmit = async (values) => {
    setServerError(null);
    try {
      const user = await login(values);
      toast.success(`${t("auth.loginTitle")}, ${user.name.split(" ")[0]}!`);
      const next = params.next;
      router.replace(next || (user.role === "ADMIN" ? "/admin" : "/home"));
    } catch (e) {
      setServerError(e.message);
    }
  };

  const fillDemo = (role) => {
    setValue("identifier", role === "admin" ? "admin@mpscpulse.in" : "student@mpscpulse.in");
    setValue("password", role === "admin" ? "Admin@123" : "Student@123");
  };

  return (
    <AuthShell>
      <div className="animate-fade-up">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
          <LogIn className="h-5.5 w-5.5" style={{ height: 22, width: 22 }} />
        </span>
        <h1 className="mt-5 text-2xl font-extrabold tracking-tight text-ink">{t("auth.loginTitle")}</h1>
        <p className="mt-1.5 text-[14px] text-muted">{t("auth.loginSub")}</p>

        {serverError ? (
          <Alert tone="danger" className="mt-5">
            {serverError}
          </Alert>
        ) : null}

        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
          <Input
            label={t("auth.identifier")}
            placeholder="you@example.com"
            autoComplete="username"
            leftIcon={User}
            error={errors.identifier?.message}
            {...register("identifier")}
          />
          <PasswordInput
            label={t("auth.password")}
            placeholder="••••••••"
            autoComplete="current-password"
            showLabel={t("auth.showPassword")}
            hideLabel={t("auth.hidePassword")}
            error={errors.password?.message}
            {...register("password")}
          />

          <div className="flex justify-end">
            <Link href="/forgot-password" className="text-[13px] font-bold text-brand-600 hover:underline">
              {t("auth.forgot")}
            </Link>
          </div>

          <Button type="submit" size="lg" fullWidth loading={isSubmitting}>
            {isSubmitting ? t("auth.loggingIn") : t("welcome.login")}
          </Button>
        </form>

        <p className="mt-5 text-center text-[13.5px] text-muted">
          {t("auth.noAccount")}{" "}
          <Link href="/language" className="font-bold text-brand-600 hover:underline">
            {t("auth.createAccount")}
          </Link>
        </p>

        <div className="mt-7 rounded-2xl border border-dashed border-slate-300 bg-white/70 p-3.5">
          <p className="flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-wide text-muted">
            <Info className="h-3.5 w-3.5" />
            {t("auth.demoHint")}
          </p>
          <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => fillDemo("student")}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-left text-[12px] transition hover:border-brand-300"
            >
              <span className="block font-bold text-ink">Student</span>
              <span className="block text-muted">student@mpscpulse.in</span>
            </button>
            <button
              type="button"
              onClick={() => fillDemo("admin")}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-left text-[12px] transition hover:border-brand-300"
            >
              <span className="block font-bold text-ink">Admin</span>
              <span className="block text-muted">admin@mpscpulse.in</span>
            </button>
          </div>
        </div>
      </div>
    </AuthShell>
  );
}
